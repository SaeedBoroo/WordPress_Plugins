<?php if (!defined('ABSPATH')) exit; ?>

<div id="chat508-widget" class="chat508-widget chat508-position-<?php echo esc_attr($this->settings['button_position'] ?? 'bottom-right'); ?>">
    <!-- Floating Chat Button -->
    <button id="chat508-toggle" class="chat508-toggle-btn" aria-label="<?php esc_attr_e('Open chat', '508-ai-chat'); ?>" aria-expanded="false" aria-controls="chat508-popup">
        <?php if (($this->settings['button_icon_type'] ?? 'default') === 'custom' && !empty($this->settings['button_custom_icon'])): ?>
            <img src="<?php echo esc_url($this->settings['button_custom_icon']); ?>" alt="<?php esc_attr_e('Chat', '508-ai-chat'); ?>" />
        <?php else: ?>
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H5.17L4 17.17V4H20V16Z" fill="currentColor"/>
                <circle cx="7" cy="9" r="1.5" fill="currentColor"/>
                <circle cx="12" cy="9" r="1.5" fill="currentColor"/>
                <circle cx="17" cy="9" r="1.5" fill="currentColor"/>
            </svg>
        <?php endif; ?>
        <span class="chat508-pulse-ring" aria-hidden="true"></span>
        <span class="chat508-notification-badge" style="display:none;">1</span>
    </button>
    
    <!-- Chat Popup -->
    <div id="chat508-popup" class="chat508-popup" role="dialog" aria-label="<?php esc_attr_e('Chat window', '508-ai-chat'); ?>" aria-hidden="true">
        <!-- Header -->
        <div class="chat508-header">
            <div class="chat508-header-info">
                <div class="chat508-avatar">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor"/>
                    </svg>
                </div>
                <div class="chat508-header-text">
                    <h3><?php _e('دستیار هوش مصنوعی', '508-ai-chat'); ?></h3>
                    <span class="chat508-status"><?php _e('آنلاین', '508-ai-chat'); ?></span>
                </div>
            </div>
            <div class="chat508-close-btn" aria-label="<?php esc_attr_e('Close chat', '508-ai-chat'); ?>">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="currentColor"/>
                </svg>
            </div>
        </div>
        
        <!-- Messages Container -->
        <div id="chat508-messages" class="chat508-messages" role="log" aria-live="polite" aria-label="<?php esc_attr_e('Chat messages', '508-ai-chat'); ?>">
            <!-- Welcome Message -->
            <div class="chat508-message chat508-message-bot">
                <div class="chat508-message-avatar">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor"/>
                    </svg>
                </div>
                <div class="chat508-message-content">
                    <div class="chat508-message-text"><?php $lang = $this->settings['chat_language'] ?? 'fa'; $ui = $this->settings['chat_ui_texts'][$lang] ?? array(); echo esc_html($ui['welcome_message'] ?? $this->settings['welcome_message'] ?? 'Hi! How can I help you today?'); ?></div>
                    <span class="chat508-message-time"><?php echo current_time('g:i A'); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Input Container -->
        <div class="chat508-input-container">
            <form id="chat508-form" class="chat508-form">
                <input 
                    type="text" 
                    id="chat508-input" 
                    class="chat508-input" 
                    placeholder="<?php esc_attr_e('پیامتان را بنویسید...', '508-ai-chat'); ?>" 
                    autocomplete="off"
                    aria-label="<?php esc_attr_e('Message input', '508-ai-chat'); ?>"
                    style="
                        background-color: var(--chat508-bg-primary) !important;
                        border: 1px solid var(--chat508-border) !important;
                    "
                />
                <button type="submit" id="chat508-send" class="chat508-send-btn" aria-label="<?php esc_attr_e('Send message', '508-ai-chat'); ?>">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M2.01 21L23 12L2.01 3L2 10L17 12L2 14L2.01 21Z" fill="currentColor"/>
                    </svg>
                </button>
            </form>
        </div>
        
        <!-- Footer -->
        <div class="chat508-footer">
            <span><?php _e('Powered by AlfaNirooAria.', '508-ai-chat'); ?></span>
        </div>
    </div>
</div>

<!-- Typing Indicator Template (hidden) -->
<template id="chat508-typing-template">
    <div class="chat508-message chat508-message-bot chat508-typing">
        <div class="chat508-message-avatar">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor"/>
            </svg>
        </div>
        <div class="chat508-message-content">
            <div class="chat508-typing-indicator">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
</template>