<?php
/**
 * Plugin Name: 508 AI Chat
 * Plugin URI: https://example.com
 * Description: Professional AI chatbot with customizable providers, knowledge base, and modern UI
 * Version: 2.0.1
 * Author: Your Name
 * Text Domain: 508-ai-chat
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

define('CHAT508_VERSION', '2.0.1');
define('CHAT508_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CHAT508_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CHAT508_PLUGIN_BASENAME', plugin_basename(__FILE__));

// =====================================================================
// 1. EXPLICITLY REQUIRE FILES (Fixes the "Class not found" error)
// =====================================================================
require_once CHAT508_PLUGIN_DIR . 'includes/class-knowledge-base.php';
require_once CHAT508_PLUGIN_DIR . 'includes/class-admin.php';
require_once CHAT508_PLUGIN_DIR . 'includes/class-api.php';
require_once CHAT508_PLUGIN_DIR . 'includes/class-frontend.php';

// =====================================================================
// 2. MAIN PLUGIN CLASS
// =====================================================================
class Chat508_Plugin {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init_hooks();
    }
    
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        add_action('plugins_loaded', array($this, 'init'));
    }
    
    public function activate() {
        $this->create_default_options();
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    private function create_default_options() {
        $default_options = array(
            'api_provider' => 'groq',
            'cerebras_api_key' => '',
            'groq_api_key' => '',
            'openai_api_key' => '',
            'custom_providers' => array(),
            'selected_model' => 'llama-3.1-8b-instant',
            'system_prompt' => 'You are a helpful assistant.',
            'knowledge_base' => '',
            'restrict_to_knowledge' => true,
            'fallback_message' => "I'm sorry, I don't have enough information to answer that question.",
            'welcome_message' => 'Hi! How can I help you today?',
            'theme' => 'light',
            'button_position' => 'bottom-right',
            'primary_color' => '#10a37f',
            'button_icon_type' => 'default',
            'button_custom_icon' => '',
            'temperature' => 0.7,
            'max_tokens' => 1000,
            'enable_sound' => false,
            'enable_typing_indicator' => true,
            'chat_history_limit' => 20
        );
        
        if (false === get_option('chat508_settings')) {
            add_option('chat508_settings', $default_options);
        }
    }
    
    public function init() {
        load_plugin_textdomain('508-ai-chat', false, dirname(CHAT508_PLUGIN_BASENAME) . '/languages');
        
        // Initialize classes with their correct namespace (\Chat508\)
        new \Chat508\Chat508_Admin();
        new \Chat508\Chat508_API();
        new \Chat508\Chat508_Frontend();
        new \Chat508\Chat508_Knowledge_Base();
    }
}

// Initialize the plugin
Chat508_Plugin::get_instance();