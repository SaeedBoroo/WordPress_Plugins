<?php
namespace Chat508;
if (!defined('ABSPATH')) exit;
class Chat508_Question_Log {
    public static function table() { global $wpdb; return $wpdb->prefix . 'chat508_questions'; }
    public static function install() {
        global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            visitor_key varchar(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            phone varchar(40) NOT NULL DEFAULT '',
            ip_hash char(64) NOT NULL DEFAULT '',
            question text NOT NULL,
            page_url text NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id), KEY visitor_key (visitor_key), KEY user_id (user_id), KEY created_at (created_at)
        ) {$charset};";
        dbDelta($sql); update_option('chat508_db_version', '1.3.0');
    }
    public static function log($question) {
        global $wpdb;
        $question = trim(sanitize_textarea_field($question));
        if ($question === '' || mb_strlen($question, 'UTF-8') > 4000) return;
        $uid = get_current_user_id();
        $phone = '';
        if ($uid) {
            foreach (array('billing_phone','phone','billing_phone_number') as $key) { $v = get_user_meta($uid, $key, true); if ($v) { $phone = sanitize_text_field($v); break; } }
        }
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        $ip_hash = $ip ? hash_hmac('sha256', $ip, wp_salt('auth')) : '';
        $visitor_key = $uid ? 'user:' . $uid : 'ip:' . ($ip_hash ?: wp_generate_uuid4());
        $referer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : '';
        $wpdb->insert(self::table(), array('visitor_key'=>$visitor_key,'user_id'=>$uid,'phone'=>$phone,'ip_hash'=>$ip_hash,'question'=>$question,'page_url'=>$referer,'created_at'=>current_time('mysql')), array('%s','%d','%s','%s','%s','%s','%s'));
    }
    public static function render_page() {
        if (!current_user_can('manage_options')) return;
        global $wpdb; $table=self::table();
        $rows=$wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 1000");
        echo '<div class="wrap"><h1>سؤالات کاربران چت‌بات</h1><p>فقط پیام‌های ارسالی کاربران ذخیره می‌شود؛ حداکثر ۱۰۰۰ سؤال اخیر نمایش داده می‌شود. کاربران واردشده با شناسه حساب و مهمان‌ها با هش IP گروه‌بندی می‌شوند.</p>';
        if (!$rows) { echo '<p>هنوز سؤالی ثبت نشده است.</p></div>'; return; }
        echo '<table class="widefat striped"><thead><tr><th>گروه کاربر</th><th>شماره تلفن</th><th>سؤال</th><th>صفحه مبدأ</th><th>زمان</th></tr></thead><tbody>';
        $seen = array();
        foreach ($rows as $r) {
            $group = $r->user_id ? 'کاربر ثبت‌نام‌شده #' . (int)$r->user_id : 'مهمان ' . substr($r->visitor_key, 3, 12);
            if ($r->user_id) { $u=get_userdata($r->user_id); if ($u) $group .= ' — ' . $u->user_login; }
            if (!isset($seen[$r->visitor_key])) { $seen[$r->visitor_key] = true; echo '<tr style="background:#eef5fb"><th colspan="5">گروه گفتگو: '.esc_html($group).'</th></tr>'; }
            echo '<tr><td>↳</td><td>'.esc_html($r->phone ?: '—').'</td><td>'.esc_html($r->question).'</td><td>'.($r->page_url ? '<a href="'.esc_url($r->page_url).'" target="_blank" rel="noopener">مشاهده صفحه</a>' : '—').'</td><td>'.esc_html($r->created_at).'</td></tr>';
        }
        echo '</tbody></table></div>';
    }
}
