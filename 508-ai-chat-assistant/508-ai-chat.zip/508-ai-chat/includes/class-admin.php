<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_Admin {
    private $settings;
    
    public function __construct() {
        $this->settings = get_option('chat508_settings', array());
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_ajax_chat508_test_connection', array($this, 'test_connection'));
        add_action('wp_ajax_chat508_save_custom_provider', array($this, 'save_custom_provider'));
        add_action('wp_ajax_chat508_delete_custom_provider', array($this, 'delete_custom_provider'));
        
    }
    
    private function get_default_translations_json() {
        $default = array(
            'en' => array(
                'header_title' => 'AI Assistant',
                'header_status' => 'Online',
                'input_placeholder' => 'Type your message...',
                'footer_text' => 'Powered by AlfaNiroo AI',
                'welcome_message' => 'Hi! How can I help you today?'
            ),
            'fa' => array(
                'header_title' => 'دستیار هوشمند',
                'header_status' => 'آنلاین',
                'input_placeholder' => 'پیام خود را بنویسید...',
                'footer_text' => 'قدرت گرفته از تیم برنامه نویسی آلفانیرو',
                'welcome_message' => 'سلام! چطور می‌توانم کمکتان کنم؟'
            ),
            'de' => array(
                'header_title' => 'KI-Assistent',
                'header_status' => 'Online',
                'input_placeholder' => 'Nachricht eingeben...',
                'footer_text' => 'Betrieben von AlfaNiroo AI',
                'welcome_message' => 'Hallo! Wie kann ich Ihnen helfen?'
            )
        );
        return json_encode($default, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('508 AI Chat', '508-ai-chat'),
            __('508 AI Chat', '508-ai-chat'),
            'manage_options',
            '508-ai-chat',
            array($this, 'render_settings_page'),
            'dashicons-format-chat',
            30
        );
        
        add_submenu_page(
            '508-ai-chat',
            __('Settings', '508-ai-chat'),
            __('Settings', '508-ai-chat'),
            'manage_options',
            '508-ai-chat',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            '508-ai-chat',
            __('Knowledge Base', '508-ai-chat'),
            __('Knowledge Base', '508-ai-chat'),
            'manage_options',
            '508-ai-chat-kb',
            array($this, 'render_knowledge_base_page')
        );
        
    }
    
    public function register_settings() {
        register_setting('chat508_settings_group', 'chat508_settings', array(
            'sanitize_callback' => array($this, 'sanitize_settings'),
            'default' => array()
        ));
    }
    
    public function sanitize_settings($input) {
    $existing = get_option('chat508_settings', array());
    
    // Force correct model based on provider if not explicitly set
    $provider = $input['api_provider'] ?? $existing['api_provider'] ?? 'cerebras';
    
    $default_models = array(
        'cerebras' => 'gpt-oss-120b',
        'groq' => 'llama-3.1-8b-instant',
        'openai' => 'gpt-4o'
    );
    
    // If model is not in input or is empty, use default for provider
    if (!isset($input['selected_model']) || empty($input['selected_model'])) {
        $input['selected_model'] = $default_models[$provider] ?? 'llama-3.1-8b-instant';
    }
    
    $sanitized = array();
    
    // ============================================
    // API Settings - Only update if present
    // ============================================
    $sanitized['api_provider'] = isset($input['api_provider']) ? sanitize_text_field($input['api_provider']) : ($existing['api_provider'] ?? 'cerebras');
    $sanitized['cerebras_api_key'] = isset($input['cerebras_api_key']) ? sanitize_text_field($input['cerebras_api_key']) : ($existing['cerebras_api_key'] ?? '');
    $sanitized['groq_api_key'] = isset($input['groq_api_key']) ? sanitize_text_field($input['groq_api_key']) : ($existing['groq_api_key'] ?? '');
    $sanitized['openai_api_key'] = isset($input['openai_api_key']) ? sanitize_text_field($input['openai_api_key']) : ($existing['openai_api_key'] ?? '');
    $sanitized['google_api_key'] = isset($input['google_api_key']) ? sanitize_text_field($input['google_api_key']) : ($existing['google_api_key'] ?? '');
    $sanitized['selected_model'] = isset($input['selected_model']) ? sanitize_text_field($input['selected_model']) : ($default_models[$provider] ?? 'llama-3.1-8b-instant');
    
    
    // Custom Providers - Preserve existing unless explicitly submitted
    if (isset($input['custom_providers']) && is_array($input['custom_providers'])) {
        $sanitized['custom_providers'] = array();
        foreach ($input['custom_providers'] as $provider) {
            if (!empty($provider['id']) && !empty($provider['name'])) {
                $sanitized['custom_providers'][] = array(
                    'id' => sanitize_text_field($provider['id']),
                    'name' => sanitize_text_field($provider['name']),
                    'base_url' => esc_url_raw($provider['base_url'] ?? ''),
                    'api_key' => sanitize_text_field($provider['api_key'] ?? ''),
                    'model' => sanitize_text_field($provider['model'] ?? ''),
                    'headers' => isset($provider['headers']) ? wp_kses_post($provider['headers']) : '',
                    'params' => isset($provider['params']) ? wp_kses_post($provider['params']) : ''
                );
            }
        }
    } else {
        // Keep existing custom providers
        $sanitized['custom_providers'] = $existing['custom_providers'] ?? array();
    }
    
    // ============================================
    // Chat Settings - Only update if present
    // ============================================
    $sanitized['system_prompt'] = isset($input['system_prompt']) ? wp_kses_post($input['system_prompt']) : ($existing['system_prompt'] ?? 'You are a helpful assistant.');
    $sanitized['knowledge_base'] = isset($input['knowledge_base']) ? wp_kses_post($input['knowledge_base']) : ($existing['knowledge_base'] ?? '');
    $sanitized['restrict_to_knowledge'] = isset($input['restrict_to_knowledge']) ? true : false;
    $sanitized['fallback_message'] = isset($input['fallback_message']) ? sanitize_text_field($input['fallback_message']) : ($existing['fallback_message'] ?? "I'm sorry, I don't have enough information to answer that question.");
    $sanitized['welcome_message'] = isset($input['welcome_message']) ? sanitize_text_field($input['welcome_message']) : ($existing['welcome_message'] ?? 'Hi! How can I help you today?');
    
    // ============================================
    // UI Settings - Only update if present
    // ============================================
    $sanitized['theme'] = isset($input['theme']) ? sanitize_text_field($input['theme']) : ($existing['theme'] ?? 'light');
    $sanitized['button_position'] = isset($input['button_position']) ? sanitize_text_field($input['button_position']) : ($existing['button_position'] ?? 'bottom-right');
    $sanitized['primary_color'] = isset($input['primary_color']) ? sanitize_hex_color($input['primary_color']) : ($existing['primary_color'] ?? '#10a37f');
    $sanitized['button_icon_type'] = isset($input['button_icon_type']) ? sanitize_text_field($input['button_icon_type']) : ($existing['button_icon_type'] ?? 'default');
    $sanitized['button_custom_icon'] = isset($input['button_custom_icon']) ? esc_url_raw($input['button_custom_icon']) : ($existing['button_custom_icon'] ?? '');
    
    // ============================================
    // Advanced Settings - Only update if present
    // ============================================
    $sanitized['temperature'] = isset($input['temperature']) ? floatval($input['temperature']) : ($existing['temperature'] ?? 0.7);
    $sanitized['max_tokens'] = isset($input['max_tokens']) ? intval($input['max_tokens']) : ($existing['max_tokens'] ?? 1000);
    $sanitized['enable_sound'] = isset($input['enable_sound']) ? true : false;
    $sanitized['enable_typing_indicator'] = isset($input['enable_typing_indicator']) ? true : false;
    $sanitized['chat_history_limit'] = isset($input['chat_history_limit']) ? intval($input['chat_history_limit']) : ($existing['chat_history_limit'] ?? 20);
    
    
    if (isset($input['translations_json'])) {
        $decoded = json_decode($input['translations_json'], true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $sanitized['translations_json'] = wp_kses_post($input['translations_json']);
        } else {
            // اگر JSON نامعتبر بود، مقدار قبلی را نگه دار
            $sanitized['translations_json'] = $existing['translations_json'] ?? $this->get_default_translations_json();
            add_settings_error('chat508_settings', 'invalid_json', __('Invalid JSON format. Previous translations restored.', '508-ai-chat'), 'error');
        }
    } else {
        $sanitized['translations_json'] = $existing['translations_json'] ?? $this->get_default_translations_json();
    }
    
    $sanitized['custom_error_message'] = isset($input['custom_error_message']) ? sanitize_textarea_field($input['custom_error_message']) : ($existing['custom_error_message'] ?? 'متأسفیم، به دلیل ترافیک بالای سرور موقتاً قادر به پاسخگویی نیستیم. لطفاً چند لحظه دیگر تلاش کنید.');
    $sanitized['custom_css'] = isset($input['custom_css']) ? wp_strip_all_tags($input['custom_css']) : ($existing['custom_css'] ?? '');
    $sanitized['chat_language'] = sanitize_text_field($input['chat_language'] ?? 'fa');
    
    return $sanitized;
    }
    
    public function render_settings_page() {
        if (!current_user_can('manage_options')) return;
        
        $settings = $this->settings;
      
        ?>
        <div class="wrap chat508-admin-wrap">
            <div class="chat508-header-actions">
                <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
                
            </div>
            
            <div class="chat508-admin-tabs">
                <nav class="nav-tab-wrapper wp-clearfix">
                    <a href="#tab-api" class="nav-tab nav-tab-active" data-tab="api">
                        <span class="dashicons dashicons-admin-network"></span>
                        <?php _e('API Providers', '508-ai-chat'); ?>
                    </a>
                    <a href="#tab-chat" class="nav-tab" data-tab="chat">
                        <span class="dashicons dashicons-format-chat"></span>
                        <?php _e('Chat Settings', '508-ai-chat'); ?>
                    </a>
                    <a href="#tab-ui" class="nav-tab" data-tab="ui">
                        <span class="dashicons dashicons-admin-appearance"></span>
                        <?php _e('Appearance', '508-ai-chat'); ?>
                    </a>
                    <a href="#tab-advanced" class="nav-tab" data-tab="advanced">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php _e('Advanced', '508-ai-chat'); ?>
                    </a>
                </nav>
                
                <form method="post" action="options.php" id="chat508-settings-form" novalidate>
                    <?php
                        // Force correct default model based on provider
                        $current_provider = $settings['api_provider'] ?? 'groq';
                        $current_model = $settings['selected_model'] ?? 'llama-3.1-8b-instant';
                        
                        // Set default model if not set or mismatched
                        if ($current_provider === 'groq' && ($current_model === '' || $current_model === 'gpt-4o')) {
                            $settings['selected_model'] = 'llama-3.1-8b-instant';
                            update_option('chat508_settings', $settings); // Save to database
                        } elseif ($current_provider === 'cerebras' && ($current_model === '' || $current_model === 'gpt-4o')) {
                            $settings['selected_model'] = 'gpt-oss-120b';
                            update_option('chat508_settings', $settings);
                        } elseif ($current_provider === 'openai' && $current_model === '') {
                            $settings['selected_model'] = 'gpt-4o';
                            update_option('chat508_settings', $settings);
                        } elseif ($provider === 'google' && ($current_model === '' || strpos($current_model, 'gpt') !== false)) {
                            $input['selected_model'] = 'gemini-2.5-flash-lite';
                        }
                        ?>
                    <?php settings_fields('chat508_settings_group'); ?>
                    
                    <!-- API Providers Tab -->
                    <div id="tab-api" class="chat508-tab-content active">
                        <div class="chat508-settings-section">
                            <h2><?php _e('Select AI Provider', '508-ai-chat'); ?></h2>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Provider', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[api_provider]" id="api-provider-select" class="regular-text">
                                            <option value="cerebras" <?php selected($settings['api_provider'], 'cerebras'); ?>>Cerebras AI</option>
                                            <option value="groq" <?php selected($settings['api_provider'], 'groq'); ?>>Groq</option>
                                            <option value="openai" <?php selected($settings['api_provider'], 'openai'); ?>>OpenAI</option>
                                            <option value="google" <?php selected($settings['api_provider'], 'google'); ?>>Google AI</option>

                                            <?php 
                                            if (!empty($settings['custom_providers'])) {
                                                echo '<optgroup label="' . esc_attr__('Custom Providers', '508-ai-chat') . '">';
                                                foreach ($settings['custom_providers'] as $provider) {
                                                    echo '<option value="custom_' . esc_attr($provider['id']) . '" ' . 
                                                         selected($settings['api_provider'], 'custom_' . $provider['id'], false) . '>' . 
                                                         esc_html($provider['name']) . '</option>';
                                                }
                                                echo '</optgroup>';
                                            }
                                            ?>
                                            <option value="add_new_custom" <?php selected($settings['api_provider'], 'add_new_custom'); ?>>➕ <?php _e('Add New Custom Provider', '508-ai-chat'); ?></option>
                                        </select>
                                        <p class="description"><?php _e('Choose your preferred AI provider', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Cerebras Settings -->
                        <div id="cerebras-settings" class="provider-settings" <?php echo $settings['api_provider'] === 'cerebras' ? '' : 'style="display:none;"'; ?>>
                            <h3><?php _e('Cerebras AI Configuration', '508-ai-chat'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('API Key', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="password" name="chat508_settings[cerebras_api_key]" 
                                               value="<?php echo esc_attr($settings['cerebras_api_key'] ?? ''); ?>" 
                                               class="regular-text" />
                                        <p class="description">
                                            <?php _e('Get your API key from', '508-ai-chat'); ?> 
                                            <a href="https://cloud.cerebras.ai/" target="_blank"><?php _e('Cerebras Cloud', '508-ai-chat'); ?></a>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Model', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[selected_model]" 
                                                id="cerebras-model-select" 
                                                class="regular-text"
                                                data-provider="cerebras">
                                            <option value="gpt-oss-120b" <?php selected($settings['selected_model'] ?? '', 'gpt-oss-120b'); ?>>GPT-OSS 120B</option>
                                            <option value="llama-3.3-70b" <?php selected($settings['selected_model'] ?? '', 'llama-3.3-70b'); ?>>Llama 3.3 70B</option>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Groq Settings -->
                        <div id="groq-settings" class="provider-settings" <?php echo $settings['api_provider'] === 'groq' ? '' : 'style="display:none;"'; ?>>
                            <h3><?php _e('Groq Configuration', '508-ai-chat'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('API Key', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="password" name="chat508_settings[groq_api_key]" 
                                               value="<?php echo esc_attr($settings['groq_api_key'] ?? ''); ?>" 
                                               class="regular-text" />
                                        <p class="description">
                                            <?php _e('Get your API key from', '508-ai-chat'); ?> 
                                            <a href="https://console.groq.com/" target="_blank"><?php _e('Groq Console', '508-ai-chat'); ?></a>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Model', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[selected_model]" 
                                                id="groq-model-select" 
                                                class="regular-text"
                                                data-provider="groq">
                                            <option value="llama-3.1-8b-instant" <?php selected($settings['selected_model'] ?? '', 'llama-3.1-8b-instant'); ?>>Llama 3.1 8B Instant</option>
                                            <option value="llama-3.3-70b-versatile" <?php selected($settings['selected_model'] ?? '', 'llama-3.3-70b-versatile'); ?>>Llama 3.3 70B Versatile</option>
                                            <option value="mixtral-8x7b-32768" <?php selected($settings['selected_model'] ?? '', 'mixtral-8x7b-32768'); ?>>Mixtral 8x7B</option>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- OpenAI Settings -->
                        <div id="openai-settings" class="provider-settings" <?php echo $settings['api_provider'] === 'openai' ? '' : 'style="display:none;"'; ?>>
                            <h3><?php _e('OpenAI Configuration', '508-ai-chat'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('API Key', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="password" name="chat508_settings[openai_api_key]" 
                                               value="<?php echo esc_attr($settings['openai_api_key'] ?? ''); ?>" 
                                               class="regular-text" />
                                        <p class="description">
                                            <?php _e('Get your API key from', '508-ai-chat'); ?> 
                                            <a href="https://platform.openai.com/api-keys" target="_blank"><?php _e('OpenAI Platform', '508-ai-chat'); ?></a>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Model', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[selected_model]" 
                                                id="openai-model-select" 
                                                class="regular-text"
                                                data-provider="openai">
                                            <option value="gpt-4o" <?php selected($settings['selected_model'] ?? '', 'gpt-4o'); ?>>GPT-4o</option>
                                            <option value="gpt-4o-mini" <?php selected($settings['selected_model'] ?? '', 'gpt-4o-mini'); ?>>GPT-4o Mini</option>
                                            <option value="gpt-4-turbo" <?php selected($settings['selected_model'] ?? '', 'gpt-4-turbo'); ?>>GPT-4 Turbo</option>
                                            <option value="o1-preview" <?php selected($settings['selected_model'] ?? '', 'o1-preview'); ?>>o1 Preview</option>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Google Settings -->
                        <div id="google-settings" class="provider-settings" <?php echo $settings['api_provider'] === 'google' ? '' : 'style="display:none;"'; ?>>
                            <h3><?php _e('Google AI Configuration', '508-ai-chat'); ?></h3>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('API Key', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="password" name="chat508_settings[google_api_key]" 
                                               value="<?php echo esc_attr($settings['google_api_key'] ?? ''); ?>" 
                                               class="regular-text" />
                                        <p class="description">
                                            <?php _e('Get your API key from', '508-ai-chat'); ?> 
                                            <a href="https://aistudio.google.com/app/apikey" target="_blank"><?php _e('Google AI Studio', '508-ai-chat'); ?></a>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Model', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[selected_model]" class="regular-text">
                                            <option value="gemini-3.1-flash-lite" <?php selected($settings['selected_model'] ?? '', 'gemini-3.1-flash-lite'); ?>>gemini-3.1-flash-lite</option>
                                            <option value="gemini-2.5-flash-lite" <?php selected($settings['selected_model'] ?? '', 'gemini-2.5-flash-lite'); ?>>gemini-2.5-flash-lite</option>
                                            <option value="gemini-2.5-pro" <?php selected($settings['selected_model'] ?? '', 'gemini-2.5-pro'); ?>>gemini-2.5-pro</option>
                                            <option value="gemini-2.5-flash" <?php selected($settings['selected_model'] ?? '', 'gemini-2.5-flash'); ?>>gemini-2.5-flash</option>
                                            <option value="gemini-embedding-2" <?php selected($settings['selected_model'] ?? '', 'gemini-embedding-2'); ?>>gemini-embedding-2</option>
                                            <option value="gemini-3.5-flash-lite" <?php selected($settings['selected_model'] ?? '', 'gemini-3.5-flash-lite'); ?>>gemini-3.5-flash-lite</option>
                                        </select>
                                        <p class="description"><?php _e('Note: Model names must exactly match Google API documentation.', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <!-- Custom Provider Settings (Inline - Only shows when selected) -->
                        <?php if (!empty($settings['custom_providers'])): ?>
                            <?php foreach ($settings['custom_providers'] as $index => $provider): ?>
                                <div id="custom-<?php echo esc_attr($provider['id']); ?>-settings" class="provider-settings" 
                                     <?php echo $settings['api_provider'] === 'custom_' . $provider['id'] ? '' : 'style="display:none;"'; ?>>
                                    <div class="provider-header">
                                        <h3><?php echo esc_html($provider['name']); ?></h3>
                                        <button type="button" class="button button-link delete-provider" data-provider-id="<?php echo esc_attr($provider['id']); ?>">
                                            <?php _e('Delete Provider', '508-ai-chat'); ?>
                                        </button>
                                    </div>
                                    <table class="form-table">
                                        <tr>
                                            <th scope="row"><?php _e('Base URL', '508-ai-chat'); ?></th>
                                            <td><input type="text" value="<?php echo esc_attr($provider['base_url']); ?>" class="regular-text" readonly /></td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><?php _e('Model', '508-ai-chat'); ?></th>
                                            <td><input type="text" value="<?php echo esc_attr($provider['model']); ?>" class="regular-text" readonly /></td>
                                        </tr>
                                        <!-- Hidden inputs to preserve custom provider data on save -->
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][id]" value="<?php echo esc_attr($provider['id']); ?>" />
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][name]" value="<?php echo esc_attr($provider['name']); ?>" />
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][base_url]" value="<?php echo esc_attr($provider['base_url']); ?>" />
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][api_key]" value="<?php echo esc_attr($provider['api_key']); ?>" />
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][model]" value="<?php echo esc_attr($provider['model']); ?>" />
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][headers]" value='<?php echo esc_attr($provider['headers']); ?>' />
                                        <input type="hidden" name="chat508_settings[custom_providers][<?php echo $index; ?>][params]" value='<?php echo esc_attr($provider['params']); ?>' />
                                    </table>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        
                        <!-- Add New Custom Provider Form (Only shows when "Add New" is selected) -->
                        <div id="add-new-custom-settings" class="provider-settings" style="display:none;">
                            <h3><?php _e('Add New Custom Provider', '508-ai-chat'); ?></h3>
                            <p class="description"><?php _e('Fill in the details below and click "Save Provider" to create a new custom AI provider.', '508-ai-chat'); ?></p>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Provider Name', '508-ai-chat'); ?></th>
                                    <td><input type="text" id="custom-provider-name" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Base API URL', '508-ai-chat'); ?></th>
                                    <td><input type="url" id="custom-provider-base-url" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('API Key', '508-ai-chat'); ?></th>
                                    <td><input type="password" id="custom-provider-api-key" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Model Name', '508-ai-chat'); ?></th>
                                    <td><input type="text" id="custom-provider-model" class="regular-text" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Custom Headers (JSON)', '508-ai-chat'); ?></th>
                                    <td>
                                        <textarea id="custom-provider-headers" class="large-text" rows="3" placeholder='{"X-Custom-Header": "value"}'></textarea>
                                        <p class="description"><?php _e('Optional: Additional headers in JSON format', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Request Parameters (JSON)', '508-ai-chat'); ?></th>
                                    <td>
                                        <textarea id="custom-provider-params" class="large-text" rows="3" placeholder='{"timeout": 30}'></textarea>
                                        <p class="description"><?php _e('Optional: Additional request parameters in JSON format', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                            <div class="modal-actions">
                                <button type="button" id="save-custom-provider" class="button button-primary">
                                    <?php _e('Save Provider', '508-ai-chat'); ?>
                                </button>
                                <button type="button" id="cancel-custom-provider" class="button">
                                    <?php _e('Cancel', '508-ai-chat'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Chat Settings Tab -->
                    <div id="tab-chat" class="chat508-tab-content">
                        <div class="chat508-settings-section">
                            <h2><?php _e('Chat Configuration', '508-ai-chat'); ?></h2>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('System Prompt', '508-ai-chat'); ?></th>
                                    <td>
                                        <textarea name="chat508_settings[system_prompt]" rows="5" class="large-text"><?php echo esc_textarea($settings['system_prompt'] ?? 'You are a helpful assistant.'); ?></textarea>
                                        <p class="description"><?php _e('Instructions for how the AI should behave', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Welcome Message', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="text" name="chat508_settings[welcome_message]" 
                                               value="<?php echo esc_attr($settings['welcome_message'] ?? 'Hi! How can I help you today?'); ?>" 
                                               class="regular-text" />
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div class="chat508-settings-section">
                            <h2><?php _e('Knowledge Base', '508-ai-chat'); ?></h2>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Enable Knowledge Base', '508-ai-chat'); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="chat508_settings[restrict_to_knowledge]" 
                                                   value="1" <?php checked($settings['restrict_to_knowledge'] ?? false, true); ?> />
                                            <?php _e('Restrict AI to only use knowledge base information', '508-ai-chat'); ?>
                                        </label>
                                        <p class="description"><?php _e('When enabled, the AI will only answer using the information you provide below', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Fallback Message', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="text" name="chat508_settings[fallback_message]" 
                                               value="<?php echo esc_attr($settings['fallback_message'] ?? "I'm sorry, I don't have enough information to answer that question."); ?>" 
                                               class="large-text" />
                                        <p class="description"><?php _e('Message shown when AI cannot find answer in knowledge base', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                            <p><a href="<?php echo admin_url('admin.php?page=508-ai-chat-kb'); ?>" class="button button-primary"><?php _e('Manage Knowledge Base', '508-ai-chat'); ?></a></p>
                            
                            
                            <div class="chat508-settings-section">
                                <h2><?php _e('Translations (JSON)', '508-ai-chat'); ?></h2>
                                <table class="form-table">
                                    <tr>
                                        <th scope="row"><?php _e('Chat Language', '508-ai-chat'); ?></th>
                                        <td>
                                            <select name="chat508_settings[chat_language]" class="regular-text">
                                                <option value="en" <?php selected($settings['chat_language'] ?? 'en', 'en'); ?>>English</option>
                                                <option value="fa" <?php selected($settings['chat_language'] ?? 'en', 'fa'); ?>>Persian (Farsi)</option>
                                                <option value="de" <?php selected($settings['chat_language'] ?? 'en', 'de'); ?>>German</option>
                                                <option value="fr" <?php selected($settings['chat_language'] ?? 'en', 'fr'); ?>>French</option>
                                                <option value="es" <?php selected($settings['chat_language'] ?? 'en', 'es'); ?>>Spanish</option>
                                                <option value="ar" <?php selected($settings['chat_language'] ?? 'en', 'ar'); ?>>Arabic</option>
                                            </select>
                                            <p class="description">
                                                <?php _e('Select the language for the chat widget. The admin interface will remain in English.', '508-ai-chat'); ?>
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><?php _e('Languages JSON', '508-ai-chat'); ?></th>
                                        <td>
                                            <textarea name="chat508_settings[translations_json]" rows="15" class="large-text code" id="chat508-translations-json" style="font-family: monospace; direction: ltr; text-align: left;"><?php echo esc_textarea($settings['translations_json'] ?? $this->get_default_translations_json()); ?></textarea>
                                            <p class="description">
                                                <?php _e('Edit translations in valid JSON format. The system will automatically detect the site language and apply the correct strings.', '508-ai-chat'); ?><br>
                                                <strong><?php _e('Warning:', '508-ai-chat'); ?></strong> <?php _e('Do not break the JSON structure (missing commas or quotes will cause errors).', '508-ai-chat'); ?>
                                            </p>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Appearance Tab -->
                    <div id="tab-ui" class="chat508-tab-content">
                        <div class="chat508-settings-section">
                            <h2><?php _e('Chat Appearance', '508-ai-chat'); ?></h2>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Theme', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[theme]" class="regular-text">
                                            <option value="light" <?php selected($settings['theme'] ?? 'light', 'light'); ?>><?php _e('Light', '508-ai-chat'); ?></option>
                                            <option value="dark" <?php selected($settings['theme'] ?? 'light', 'dark'); ?>><?php _e('Dark', '508-ai-chat'); ?></option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Button Position', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[button_position]" class="regular-text">
                                            <option value="bottom-right" <?php selected($settings['button_position'] ?? 'bottom-right', 'bottom-right'); ?>><?php _e('Bottom Right', '508-ai-chat'); ?></option>
                                            <option value="bottom-left" <?php selected($settings['button_position'] ?? 'bottom-right', 'bottom-left'); ?>><?php _e('Bottom Left', '508-ai-chat'); ?></option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Primary Color', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="color" name="chat508_settings[primary_color]" 
                                               value="<?php echo esc_attr($settings['primary_color'] ?? '#10a37f'); ?>" 
                                               class="chat508-color-picker" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Button Icon', '508-ai-chat'); ?></th>
                                    <td>
                                        <select name="chat508_settings[button_icon_type]" id="button-icon-type" class="regular-text">
                                            <option value="default" <?php selected($settings['button_icon_type'] ?? 'default', 'default'); ?>><?php _e('Default Icon', '508-ai-chat'); ?></option>
                                            <option value="custom" <?php selected($settings['button_icon_type'] ?? 'default', 'custom'); ?>><?php _e('Custom Icon', '508-ai-chat'); ?></option>
                                        </select>
                                    </td>
                                </tr>
                                <tr id="custom-icon-upload-row" style="<?php echo ($settings['button_icon_type'] ?? 'default') === 'custom' ? '' : 'display:none;'; ?>">
                                    <th scope="row"><?php _e('Custom Icon URL', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="url" name="chat508_settings[button_custom_icon]" 
                                               id="button-custom-icon"
                                               value="<?php echo esc_attr($settings['button_custom_icon'] ?? ''); ?>" 
                                               class="regular-text" />
                                        <button type="button" class="button" id="upload-button-icon">
                                            <?php _e('Upload Icon', '508-ai-chat'); ?>
                                        </button>
                                        <?php if (!empty($settings['button_custom_icon'])): ?>
                                            <img src="<?php echo esc_url($settings['button_custom_icon']); ?>" style="max-width: 50px; margin-left: 10px; vertical-align: middle;" />
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Advanced Tab -->
                    <div id="tab-advanced" class="chat508-tab-content">
                        <div class="chat508-settings-section">
                            <h2><?php _e('Advanced Settings', '508-ai-chat'); ?></h2>
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Temperature', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="number" name="chat508_settings[temperature]" 
                                               value="<?php echo esc_attr($settings['temperature'] ?? 0.7); ?>" 
                                               min="0" max="2" step="0.1" class="small-text" />
                                        <p class="description"><?php _e('Controls randomness (0 = focused, 2 = creative)', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Max Tokens', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="number" name="chat508_settings[max_tokens]" 
                                               value="<?php echo esc_attr($settings['max_tokens'] ?? 1000); ?>" 
                                               min="100" max="4000" class="small-text" />
                                        <p class="description"><?php _e('Maximum length of AI response', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Enable Sound Effects', '508-ai-chat'); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="chat508_settings[enable_sound]" 
                                                   value="1" <?php checked($settings['enable_sound'] ?? false, true); ?> />
                                            <?php _e('Play sound on new messages', '508-ai-chat'); ?>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Show Typing Indicator', '508-ai-chat'); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="chat508_settings[enable_typing_indicator]" 
                                                   value="1" <?php checked($settings['enable_typing_indicator'] ?? true, true); ?> />
                                            <?php _e('Show typing animation while AI is responding', '508-ai-chat'); ?>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Chat History Limit', '508-ai-chat'); ?></th>
                                    <td>
                                        <input type="number" name="chat508_settings[chat_history_limit]" 
                                               value="<?php echo esc_attr($settings['chat_history_limit'] ?? 20); ?>" 
                                               min="5" max="100" class="small-text" />
                                        <p class="description"><?php _e('Number of messages to keep in conversation history', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <th scope="row"><?php _e('Custom Error Message', '508-ai-chat'); ?></th>
                                    <td>
                                        <textarea name="chat508_settings[custom_error_message]" rows="3" class="large-text"><?php echo esc_textarea($settings['custom_error_message'] ?? 'متأسفیم، به دلیل ترافیک بالای سرور موقتاً قادر به پاسخگویی نیستیم. لطفاً چند لحظه دیگر تلاش کنید.'); ?></textarea>
                                        <p class="description"><?php _e('This message will be shown to the user if the AI API fails, hits a rate limit, or encounters any error.', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Custom CSS', '508-ai-chat'); ?></th>
                                    <td>
                                        <textarea name="chat508_settings[custom_css]" rows="12" class="large-text code" style="font-family: monospace; direction: ltr; text-align: left;" placeholder=".chat508-message-user .chat508-message-text { background: #ff0000; }"><?php echo esc_textarea($settings['custom_css'] ?? ''); ?></textarea>
                                        <p class="description"><?php _e('Add your own CSS rules here to override the default chat appearance. No need for &lt;style&gt; tags.', '508-ai-chat'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <?php submit_button(__('Save Settings', '508-ai-chat')); ?>
                </form>
            </div>
        </div>
        <?php
    }
    
    public function render_knowledge_base_page() {
        if (!current_user_can('manage_options')) return;
        
        $settings = $this->settings;
        
        ?>
        <div class="wrap">
            <div class="chat508-header-actions">
                <h1><?php _e('Knowledge Base Management', '508-ai-chat'); ?></h1>
                
            </div>
            
            <div class="chat508-kb-info">
                <p><?php _e('Add your business information, FAQs, product details, and any other content you want the AI to use when answering questions.', '508-ai-chat'); ?></p>
                <p><?php _e('The AI will prioritize this information when responding to user queries.', '508-ai-chat'); ?></p>
            </div>
            
            <form method="post" action="options.php">
                <?php settings_fields('chat508_settings_group'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Knowledge Base Content', '508-ai-chat'); ?></th>
                        <td>
                            <textarea name="chat508_settings[knowledge_base]" rows="20" class="large-text code" placeholder="<?php esc_attr_e('Enter your knowledge base content here...', '508-ai-chat'); ?>"><?php echo esc_textarea($settings['knowledge_base'] ?? ''); ?></textarea>
                            <p class="description">
                                <?php _e('You can add unlimited text. The AI will use this information to answer questions.', '508-ai-chat'); ?><br>
                                <?php _e('Format: You can use plain text, or organize with sections, bullet points, etc.', '508-ai-chat'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Save Knowledge Base', '508-ai-chat')); ?>
            </form>
            
            <div class="chat508-kb-tips">
                <h3><?php _e('Tips for Effective Knowledge Base', '508-ai-chat'); ?></h3>
                <ul>
                    <li><?php _e('Be specific and detailed in your information', '508-ai-chat'); ?></li>
                    <li><?php _e('Include common questions and their answers', '508-ai-chat'); ?></li>
                    <li><?php _e('Organize content with clear headings', '508-ai-chat'); ?></li>
                    <li><?php _e('Update regularly to keep information current', '508-ai-chat'); ?></li>
                    <li><?php _e('Use natural language that matches how users ask questions', '508-ai-chat'); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, '508-ai-chat') === false) return;
        
        wp_enqueue_media();
        wp_enqueue_style('chat508-admin', CHAT508_PLUGIN_URL . 'assets/css/admin.css', array(), CHAT508_VERSION);
        wp_enqueue_script('chat508-admin', CHAT508_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), CHAT508_VERSION, true);
        
        wp_localize_script('chat508-admin', 'chat508Admin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('chat508_admin_nonce'),
            'strings' => array(
                'confirmDelete' => __('Are you sure you want to delete this provider?', '508-ai-chat'),
                'saving' => __('Saving...', '508-ai-chat'),
                'saved' => __('Saved successfully', '508-ai-chat'),
                'error' => __('An error occurred', '508-ai-chat'),
                'selectIcon' => __('Select Icon', '508-ai-chat'),
                'useIcon' => __('Use Icon', '508-ai-chat'),
                'fillAllFields' => __('Please fill in all required fields', '508-ai-chat'),
                'invalidJson' => __('Must be valid JSON format', '508-ai-chat')
            )
        ));
    }
    
    public function test_connection() {
        check_ajax_referer('chat508_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', '508-ai-chat')));
        }
        
        wp_send_json_success(array('message' => __('Connection successful', '508-ai-chat')));
    }
    
    public function save_custom_provider() {
        check_ajax_referer('chat508_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', '508-ai-chat')));
        }
        
        $name = sanitize_text_field($_POST['name'] ?? '');
        $base_url = esc_url_raw($_POST['base_url'] ?? '');
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $model = sanitize_text_field($_POST['model'] ?? '');
        
        if (empty($name) || empty($base_url) || empty($api_key) || empty($model)) {
            wp_send_json_error(array('message' => __('Please fill in all required fields', '508-ai-chat')));
        }
        
        $settings = get_option('chat508_settings');
        
        $new_provider = array(
            'id' => uniqid('cp_'),
            'name' => $name,
            'base_url' => $base_url,
            'api_key' => $api_key,
            'model' => $model,
            'headers' => wp_kses_post($_POST['headers'] ?? ''),
            'params' => wp_kses_post($_POST['params'] ?? '')
        );
        
        if (!isset($settings['custom_providers'])) {
            $settings['custom_providers'] = array();
        }
        
        $settings['custom_providers'][] = $new_provider;
        update_option('chat508_settings', $settings);
        
        wp_send_json_success(array(
            'provider' => $new_provider,
            'message' => __('Provider saved successfully', '508-ai-chat')
        ));
    }
    
    public function delete_custom_provider() {
        check_ajax_referer('chat508_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', '508-ai-chat')));
        }
        
        $provider_id = sanitize_text_field($_POST['provider_id']);
        $settings = get_option('chat508_settings');
        
        if (isset($settings['custom_providers']) && is_array($settings['custom_providers'])) {
            $settings['custom_providers'] = array_values(array_filter($settings['custom_providers'], function($p) use ($provider_id) {
                return $p['id'] !== $provider_id;
            }));
        }
        
        update_option('chat508_settings', $settings);
        
        wp_send_json_success(array('message' => __('Provider deleted', '508-ai-chat')));
    }

}