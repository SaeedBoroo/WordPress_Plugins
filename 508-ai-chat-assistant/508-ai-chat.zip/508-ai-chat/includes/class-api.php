<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_API {
    private $settings;
    private $knowledge_base;
    
    public function __construct() {
        // Load settings from database
        $this->settings = get_option('chat508_settings', array());
        $this->knowledge_base = new Chat508_Knowledge_Base();
        
        // Log settings for debugging (optional)
        // error_log('Chat508 Settings: ' . print_r($this->settings, true));
        
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        register_rest_route('chat508/v1', '/chat', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_chat'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('chat508/v1', '/test', array(
            'methods' => 'POST',
            'callback' => array($this, 'test_connection'),
            'permission_callback' => '__return_true'
        ));
    }
    
   public function handle_chat($request) {
        $user_message = sanitize_text_field($request->get_param('message'));
        $conversation = $request->get_param('conversation') ?? array();
        
        if (empty($user_message)) {
            return rest_ensure_response(array(
                'success' => false,
                'error' => 'Message cannot be empty'
            ));
        }
        
        try {
            $response = $this->call_ai_api($user_message, $conversation);
            
            return rest_ensure_response(array(
                'success' => true,
                'message' => $response,
                'timestamp' => time()
            ));
        } catch (\Exception $e) {
            // 1. خطای واقعی (مثل Rate Limit) را فقط در لاگ سرور ذخیره کن (کاربر این را نمی‌بیند)
            error_log('Chat508 REAL API ERROR: ' . $e->getMessage());
            
            // 2. به فرانت‌اند فقط یک پرچم خطای عمومی بفرست
            return rest_ensure_response(array(
                'success' => false,
                'error_code' => 'api_failure',
                'error' => 'یک دقیقه صبر کنید. دوباره تلاش کنید'
            ));
        }
    }
    
    private function call_ai_api($user_message, $conversation) {
        // Get provider from settings
        $provider = $this->settings['api_provider'] ?? 'cerebras';
        
        // Debug log
        error_log('Chat508 - Selected Provider: ' . $provider);
        error_log('Chat508 - Selected Model: ' . ($this->settings['selected_model'] ?? 'not set'));
        
        // Build messages array with system prompt
        $system_prompt = $this->knowledge_base->build_system_prompt();
        
        $messages = array(
            array(
                'role' => 'system',
                'content' => $system_prompt
            )
        );
        
        // Add conversation history (limit to last N messages)
        $history_limit = $this->settings['chat_history_limit'] ?? 20;
        $recent_conversation = array_slice($conversation, -$history_limit);
        
        foreach ($recent_conversation as $msg) {
            $messages[] = array(
                'role' => $msg['role'],
                'content' => sanitize_text_field($msg['content'])
            );
        }
        
        // Add current user message
        $messages[] = array(
            'role' => 'user',
            'content' => $user_message
        );
        
        // Route to appropriate provider
        if (strpos($provider, 'custom_') === 0) {
            return $this->call_custom_provider($messages, $provider);
        }
        
        switch ($provider) {
            case 'cerebras':
                return $this->call_cerebras($messages);
            case 'groq':
                return $this->call_groq($messages);
            case 'openai':
                return $this->call_openai($messages);
            case 'google':
                return $this->call_google_gemini($messages);
            default:
                throw new \Exception('Invalid provider selected: ' . $provider);
        }
    }
    
    private function call_cerebras($messages) {
        $api_key = $this->settings['cerebras_api_key'] ?? '';
        $model = $this->settings['selected_model'] ?? '';
        
        if (empty($api_key)) {
            throw new \Exception('Cerebras API key is not configured');
        }
        
        error_log('Chat508 - Calling Cerebras with model: ' . $model);
        
        $response = wp_remote_post('https://api.cerebras.ai/v1/chat/completions', array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => json_encode(array(
                'model' => $model,
                'messages' => $messages,
                'temperature' => $this->settings['temperature'] ?? 0.7,
                'max_tokens' => $this->settings['max_tokens'] ?? 1000
            )),
            'timeout' => 60
        ));
        
        return $this->parse_response($response, 'Cerebras');
    }
    
    private function call_groq($messages) {
        $api_key = $this->settings['groq_api_key'] ?? '';
        $model = $this->settings['selected_model'] ?? '';
        
        if (empty($api_key)) {
            throw new \Exception('Groq API key is not configured');
        }
        
        error_log('Chat508 - Calling Groq with model: ' . $model);
        
        $response = wp_remote_post('https://api.groq.com/openai/v1/chat/completions', array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => json_encode(array(
                'model' => $model,
                'messages' => $messages,
                'temperature' => $this->settings['temperature'] ?? 0.7,
                'max_tokens' => $this->settings['max_tokens'] ?? 1000
            )),
            'timeout' => 60
        ));
        
        return $this->parse_response($response, 'Groq');
    }
    
    private function call_openai($messages) {
        $api_key = $this->settings['openai_api_key'] ?? '';
        $model = $this->settings['selected_model'] ?? '';
        
        if (empty($api_key)) {
            throw new \Exception('OpenAI API key is not configured');
        }
        
        error_log('Chat508 - Calling OpenAI with model: ' . $model);
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => json_encode(array(
                'model' => $model,
                'messages' => $messages,
                'temperature' => $this->settings['temperature'] ?? 0.7,
                'max_tokens' => $this->settings['max_tokens'] ?? 1000
            )),
            'timeout' => 60
        ));
        
        return $this->parse_response($response, 'OpenAI');
    }
    
    private function call_google_gemini($messages) {
        $api_key = $this->settings['google_api_key'] ?? '';
        $model = $this->settings['selected_model'] ?? 'gemini-1.5-flash';
        
        if (empty($api_key)) {
            throw new \Exception('Google API key is not configured');
        }
        
        error_log('Chat508 - Calling Google with model: ' . $model);
        
        // تبدیل ساختار OpenAI به ساختار Google
        $contents = [];
        $system_instruction = '';
        
        foreach ($messages as $msg) {
            if ($msg['role'] === 'system') {
                $system_instruction = $msg['content'];
            } else {
                $role = ($msg['role'] === 'assistant') ? 'model' : 'user';
                $contents[] = [
                    'role' => $role,
                    'parts' => [['text' => $msg['content']]]
                ];
            }
        }
        
        $payload = [
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => $this->settings['temperature'] ?? 0.7,
                'maxOutputTokens' => $this->settings['max_tokens'] ?? 1000
            ]
        ];
        
        // اضافه کردن دستورات سیستمی اگر وجود داشته باشد
        if (!empty($system_instruction)) {
            $payload['systemInstruction'] = [
                'parts' => [['text' => $system_instruction]]
            ];
        }
        
        // آدرس API گوگل (v1beta برای مدل‌های جدید مثل Gemma 3 و Gemini 2.0)
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$api_key}";
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($payload),
            'timeout' => 60
        ));
        
        return $this->parse_google_response($response, $model);
    }
    
    private function parse_google_response($response, $model_name) {
        if (is_wp_error($response)) {
            throw new \Exception('Google API request failed: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        // بررسی خطاهای گوگل (مثل quota exceeded یا invalid model)
        if (isset($body['error'])) {
            $error_msg = $body['error']['message'] ?? 'Unknown Google API error';
            error_log('Google API Error: ' . $error_msg);
            throw new \Exception($error_msg);
        }
        
        // استخراج متن از ساختار خاص گوگل
        if (!isset($body['candidates']) || !isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            error_log('Google Invalid response: ' . print_r($body, true));
            throw new \Exception('Invalid response format from Google API');
        }
        
        return $body['candidates'][0]['content']['parts'][0]['text'];
    }
    
    private function call_custom_provider($messages, $provider_id) {
        $custom_providers = $this->settings['custom_providers'] ?? array();
        $provider_id = str_replace('custom_', '', $provider_id);
        
        $provider = null;
        foreach ($custom_providers as $p) {
            if ($p['id'] === $provider_id) {
                $provider = $p;
                break;
            }
        }
        
        if (!$provider) {
            throw new \Exception('Custom provider not found: ' . $provider_id);
        }
        
        if (empty($provider['api_key'])) {
            throw new \Exception('Custom provider API key is not configured');
        }
        
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $provider['api_key']
        );
        
        // Add custom headers if provided
        if (!empty($provider['headers'])) {
            $custom_headers = json_decode($provider['headers'], true);
            if (is_array($custom_headers)) {
                $headers = array_merge($headers, $custom_headers);
            }
        }
        
        $request_body = array(
            'model' => $provider['model'],
            'messages' => $messages,
            'temperature' => $this->settings['temperature'] ?? 0.7,
            'max_tokens' => $this->settings['max_tokens'] ?? 1000
        );
        
        // Add custom parameters if provided
        if (!empty($provider['params'])) {
            $custom_params = json_decode($provider['params'], true);
            if (is_array($custom_params)) {
                $request_body = array_merge($request_body, $custom_params);
            }
        }
        
        error_log('Chat508 - Calling Custom Provider: ' . $provider['name'] . ' with model: ' . $provider['model']);
        
        $response = wp_remote_post($provider['base_url'], array(
            'headers' => $headers,
            'body' => json_encode($request_body),
            'timeout' => 60
        ));
        
        return $this->parse_response($response, 'Custom: ' . $provider['name']);
    }
    
    private function parse_response($response, $provider_name = 'API') {
        if (is_wp_error($response)) {
            throw new \Exception($provider_name . ' request failed: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        // Check for API error
        if (isset($body['error'])) {
            $error_msg = $body['error']['message'] ?? 'Unknown API error';
            error_log($provider_name . ' API Error: ' . $error_msg);
            throw new \Exception($error_msg);
        }
        
        // Check for valid response
        if (!isset($body['choices']) || !isset($body['choices'][0]['message']['content'])) {
            error_log($provider_name . ' Invalid response: ' . print_r($body, true));
            throw new \Exception('Invalid response from ' . $provider_name . ' API');
        }
        
        return $body['choices'][0]['message']['content'];
    }
    
    public function test_connection($request) {
        try {
            $test_message = "This is a test message. Please respond with 'Connection successful'.";
            $response = $this->call_ai_api($test_message, array());
            
            return rest_ensure_response(array(
                'success' => true,
                'message' => 'Connection successful',
                'response' => $response
            ));
        } catch (\Exception $e) {
            return rest_ensure_response(array(
                'success' => false,
                'error' => $e->getMessage()
            ));
        }
    }
}