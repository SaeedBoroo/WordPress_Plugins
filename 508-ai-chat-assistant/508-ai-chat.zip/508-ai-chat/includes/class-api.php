<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_API {
    private $settings;
    private $knowledge_base;
    
    // لیست مدل‌های پشتیبان برای هر پرووایدر
    private $provider_models = array(
        'groq' => array('llama-3.1-8b-instant', 'llama-3.3-70b-versatile', 'mixtral-8x7b-32768'),
        // 'cerebras' => array('gpt-oss-120b', 'llama-3.3-70b'),
        // 'openai' => array('gpt-4o-mini', 'gpt-4o', 'gpt-3.5-turbo'),
        'google' => array('gemini-3.1-flash-lite', 'gemini-2.5-flash-lite', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-3.5-flash-lite')
    );

    public function __construct() {
        $this->settings = get_option('chat508_settings', array());
        $this->knowledge_base = new Chat508_Knowledge_Base();
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        register_rest_route('chat508/v1', '/chat', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_chat'),
            'permission_callback' => '__return_true'
        ));
    }
    
    public function handle_chat($request) {
        $user_message = sanitize_text_field($request->get_param('message'));
        $conversation = $request->get_param('conversation') ?? array();
        
        if (empty($user_message)) {
            return rest_ensure_response(array('success' => false, 'error' => 'Message cannot be empty'));
        }
        
        try {
            // استفاده از سیستم جدید با قابلیت Failover
            $response = $this->call_ai_with_failover($user_message, $conversation);
            
            return rest_ensure_response(array(
                'success' => true,
                'message' => $response,
                'timestamp' => time()
            ));
        } catch (\Exception $e) {
            error_log('Chat508 FINAL ERROR: ' . $e->getMessage());
            return rest_ensure_response(array(
                'success' => false,
                'error_code' => 'api_failure',
                'error' => 'خطا، بعد از یک دقیقه صبر دوباره پیام دهید'
            ));
        }
    }

    /**
     * سیستم هوشمند فراخوانی API با قابلیت سوئیچ خودکار
     */
    private function call_ai_with_failover($user_message, $conversation) {
        $enable_failover = $this->settings['enable_failover'] ?? false;
        $primary_provider = $this->settings['api_provider'] ?? 'groq';
        $primary_model = $this->settings['selected_model'] ?? '';
        error_log("Chat508 : Trying model '{$primary_model}' on '{$primary_provider}'");
        // ساخت پیام‌ها
        $system_prompt = $this->knowledge_base->build_system_prompt();
        $messages = array(array('role' => 'system', 'content' => $system_prompt));
        
        $history_limit = $this->settings['chat_history_limit'] ?? 20;
        foreach (array_slice($conversation, -$history_limit) as $msg) {
            $messages[] = array('role' => $msg['role'], 'content' => sanitize_text_field($msg['content']));
        }
        $messages[] = array('role' => 'user', 'content' => $user_message);

        // 1. تلاش با پرووایدر و مدل اصلی
        try {
            return $this->execute_provider_call($primary_provider, $primary_model, $messages);
        } catch (\Exception $e) {
            error_log("Chat508 Primary Failed: {$primary_provider}/{$primary_model} -> " . $e->getMessage());
            if (!$enable_failover) throw $e;
        }

        if (!$enable_failover) throw new \Exception('Primary provider failed and failover is disabled.');

        // 2. تلاش با سایر مدل‌های همان پرووایدر
        $models_to_try = $this->provider_models[$primary_provider] ?? array();
        foreach ($models_to_try as $model) {
            if ($model === $primary_model) continue;
            try {
                error_log("Chat508 Failover: Trying model {$model} on {$primary_provider}");
                return $this->execute_provider_call($primary_provider, $model, $messages);
            } catch (\Exception $e) {
                error_log("Chat508 Model Failover Failed: {$model} -> " . $e->getMessage());
            }
        }

        // 3. تلاش با سایر پرووایدرها
        $fallback_providers = array_diff(array_keys($this->provider_models), array($primary_provider));
        foreach ($fallback_providers as $provider) {
            // بررسی اینکه آیا API Key برای این پرووایدر تنظیم شده است؟
            if (!$this->has_api_key($provider)) continue;

            foreach ($this->provider_models[$provider] as $model) {
                try {
                    error_log("Chat508 Provider Failover: Trying {$provider}/{$model}");
                    return $this->execute_provider_call($provider, $model, $messages);
                } catch (\Exception $e) {
                    error_log("Chat508 Provider Failover Failed: {$provider}/{$model} -> " . $e->getMessage());
                }
            }
        }

        throw new \Exception('All providers and models failed.');
    }

    private function has_api_key($provider) {
        $key_map = array(
            'groq' => 'groq_api_key',
            'cerebras' => 'cerebras_api_key',
            'openai' => 'openai_api_key',
            'google' => 'google_api_key'
        );
        return !empty($this->settings[$key_map[$provider]]);
    }

    private function execute_provider_call($provider, $model, $messages) {
        // اگر مدل خالی بود، اولین مدل لیست را بردار
        if (empty($model) && isset($this->provider_models[$provider])) {
            $model = $this->provider_models[$provider][0];
        }

        switch ($provider) {
            case 'cerebras': return $this->call_cerebras($messages, $model);
            case 'groq': return $this->call_groq($messages, $model);
            case 'openai': return $this->call_openai($messages, $model);
            case 'google': return $this->call_google_gemini($messages, $model);
            default: throw new \Exception("Unknown provider: {$provider}");
        }
    }

    // --- توابع فراخوانی API (با دریافت مدل به عنوان پارامتر) ---

    private function call_cerebras($messages, $model = null) {
        $api_key = $this->settings['cerebras_api_key'];
        if (empty($api_key)) throw new \Exception('Cerebras API key missing');
        $model = $model ?: ($this->settings['selected_model'] ?? 'gpt-oss-120b');
        
        $response = wp_remote_post('https://api.cerebras.ai/v1/chat/completions', array(
            'headers' => array('Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $api_key),
            'body' => json_encode(array('model' => $model, 'messages' => $messages, 'temperature' => $this->settings['temperature'] ?? 0.7, 'max_tokens' => $this->settings['max_tokens'] ?? 1000)),
            'timeout' => 60
        ));
        return $this->parse_response($response);
    }

    private function call_groq($messages, $model = null) {
        $api_key = $this->settings['groq_api_key'];
        if (empty($api_key)) throw new \Exception('Groq API key missing');
        $model = $model ?: ($this->settings['selected_model'] ?? 'llama-3.1-8b-instant');
        
        $response = wp_remote_post('https://api.groq.com/openai/v1/chat/completions', array(
            'headers' => array('Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $api_key),
            'body' => json_encode(array('model' => $model, 'messages' => $messages, 'temperature' => $this->settings['temperature'] ?? 0.7, 'max_tokens' => $this->settings['max_tokens'] ?? 1000)),
            'timeout' => 60
        ));
        return $this->parse_response($response);
    }

    private function call_openai($messages, $model = null) {
        $api_key = $this->settings['openai_api_key'];
        if (empty($api_key)) throw new \Exception('OpenAI API key missing');
        $model = $model ?: ($this->settings['selected_model'] ?? 'gpt-4o-mini');
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => array('Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $api_key),
            'body' => json_encode(array('model' => $model, 'messages' => $messages, 'temperature' => $this->settings['temperature'] ?? 0.7, 'max_tokens' => $this->settings['max_tokens'] ?? 1000)),
            'timeout' => 60
        ));
        return $this->parse_response($response);
    }

    private function call_google_gemini($messages, $model = null) {
        $api_key = $this->settings['google_api_key'];
        if (empty($api_key)) throw new \Exception('Google API key missing');
        $model = $model ?: ($this->settings['selected_model'] ?? 'gemini-1.5-flash');
        
        $contents = []; $system_instruction = '';
        foreach ($messages as $msg) {
            if ($msg['role'] === 'system') $system_instruction = $msg['content'];
            else $contents[] = ['role' => ($msg['role'] === 'assistant' ? 'model' : 'user'), 'parts' => [['text' => $msg['content']]]];
        }
        
        $payload = ['contents' => $contents, 'generationConfig' => ['temperature' => $this->settings['temperature'] ?? 0.7, 'maxOutputTokens' => $this->settings['max_tokens'] ?? 1000]];
        if (!empty($system_instruction)) $payload['systemInstruction'] = ['parts' => [['text' => $system_instruction]]];
        
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$api_key}";
        $response = wp_remote_post($url, array('headers' => array('Content-Type' => 'application/json'), 'body' => json_encode($payload), 'timeout' => 60));
        
        if (is_wp_error($response)) throw new \Exception($response->get_error_message());
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['error'])) throw new \Exception($body['error']['message']);
        if (!isset($body['candidates'][0]['content']['parts'][0]['text'])) throw new \Exception('Invalid Google response');
        return $body['candidates'][0]['content']['parts'][0]['text'];
    }

    private function parse_response($response) {
        if (is_wp_error($response)) throw new \Exception($response->get_error_message());
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['error'])) throw new \Exception($body['error']['message']);
        if (!isset($body['choices'][0]['message']['content'])) throw new \Exception('Invalid API response');
        return $body['choices'][0]['message']['content'];
    }
}