<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_Knowledge_Base {
    private $knowledge_base;
    private $settings;
    
    public function __construct() {
        $this->settings = get_option('chat508_settings', array());
        $this->knowledge_base = $this->settings['knowledge_base'] ?? '';
    }
    
    /**
     * Get the knowledge base content
     */
    public function get_content() {
        return $this->knowledge_base;
    }
    
    /**
     * Check if knowledge base is enabled and has content
     */
    public function is_active() {
        return !empty($this->knowledge_base) && ($this->settings['restrict_to_knowledge'] ?? false);
    }
    
    /**
     * Build system prompt with knowledge base
     */
    public function build_system_prompt($base_prompt = '') {
        $system_prompt = $base_prompt ?: ($this->settings['system_prompt'] ?? 'You are a helpful assistant.');
        
        if (!$this->is_active()) {
            return $system_prompt;
        }
        
        $fallback_message = $this->settings['fallback_message'] ?? "I'm sorry, I don't have enough information to answer that question.";
        
        $knowledge_prompt = sprintf(
            "\n\nIMPORTANT INSTRUCTIONS:\n" .
            "You have access to the following knowledge base:\n\n" .
            "=== KNOWLEDGE BASE ===\n%s\n=== END KNOWLEDGE BASE ===\n\n" .
            "CRITICAL RULES:\n" .
            "1. You MUST answer questions using ONLY the information provided in the knowledge base above.\n" .
            "2. Do NOT use your general knowledge or make assumptions.\n" .
            "3. Do NOT fabricate or infer information that is not explicitly stated.\n" .
            "4. If the user asks something not covered in the knowledge base, respond with: \"%s\"\n" .
            "5. Be concise and accurate. Only provide information that exists in the knowledge base.\n" .
            "6. If asked about topics outside the knowledge base, politely decline and remind users you can only help with the provided information.",
            $this->knowledge_base,
            $fallback_message
        );
        
        return $system_prompt . $knowledge_prompt;
    }
    
    /**
     * Search knowledge base for relevant information
     */
    public function search($query) {
        if (empty($this->knowledge_base)) {
            return '';
        }
        
        // Simple keyword matching - can be enhanced with more sophisticated algorithms
        $query_words = array_filter(explode(' ', strtolower($query)));
        $kb_content = $this->knowledge_base;
        
        // Return full knowledge base for now (AI will filter)
        // In production, you might want to implement vector search or more advanced retrieval
        return $kb_content;
    }
    
    /**
     * Validate if answer is based on knowledge base
     */
    public function validate_answer($answer) {
        if (!$this->is_active()) {
            return true;
        }
        
        // This is a simple check - in production, you might want more sophisticated validation
        return !empty($answer);
    }
}