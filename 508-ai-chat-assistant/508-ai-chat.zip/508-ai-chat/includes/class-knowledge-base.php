<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_Knowledge_Base {
    private $knowledge_base;
    private $settings;
    private $synced_content = '';
    private $synced_last_run = 0;

    public function __construct() {
        $this->settings = get_option('chat508_settings', array());
        $this->knowledge_base = $this->settings['knowledge_base'] ?? '';
        $legacy_synced = (string) ($this->settings['synced_content'] ?? '');
        $stored_synced = get_option('chat508_synced_knowledge', null);
        if ($stored_synced === null && $legacy_synced !== '') { update_option('chat508_synced_knowledge', $legacy_synced, false); $stored_synced = $legacy_synced; }
        $this->synced_content = is_string($stored_synced) ? $stored_synced : $legacy_synced;
        $this->synced_last_run = (int) get_option('chat508_synced_last_run', $this->settings['synced_last_run'] ?? 0);
    }

    /**
     * Get the knowledge base content
     */
    public function get_content() {
        return $this->knowledge_base;
    }

    /**
     * Check if knowledge base is enabled and has content
     */
    public function is_active() {
        $effective_content = $this->get_effective_content();
        $restrict = $this->settings['restrict_to_knowledge'] ?? false;
        return !empty($effective_content) && $restrict;
    }

    /**
     * Get the effective knowledge base content (synced or manual)
     */
    public function get_effective_content() {
        $sync_enabled = !empty($this->settings['sync_content_enabled']);
        $manual = trim((string) $this->knowledge_base);
        $synced = $sync_enabled ? trim((string) $this->synced_content) : '';
        if ($manual !== '' && $synced !== '') return $manual . "\n\n=== محتوای همگام‌سازی‌شده وردپرس ===\n\n" . $synced;
        return $synced !== '' ? $synced : $manual;
    }

    /**
     * Sync WordPress content from posts, pages, and products
     */
    public function sync_content() {
        $post_types = array('post', 'page', 'product');
        $content_parts = array(); $total_posts = 0; $error_count = 0;
        foreach ($post_types as $post_type) {
            if (!post_type_exists($post_type)) continue;
            $page = 1; $batch_size = 100;
            while (true) {
                $query = new \WP_Query(array(
                    'post_type' => $post_type, 'post_status' => 'publish',
                    'posts_per_page' => $batch_size, 'paged' => $page,
                    'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC',
                    'no_found_rows' => true, 'ignore_sticky_posts' => true,
                ));
                if (empty($query->posts)) break;
                foreach ($query->posts as $post_id) {
                    $total_posts++;
                    try {
                        $title = get_the_title($post_id);
                        $body = (string) get_post_field('post_content', $post_id);
                        $excerpt = (string) get_post_field('post_excerpt', $post_id);
                        $plain = array();
                        foreach (array($body, $excerpt) as $part) {
                            $part = strip_shortcodes($part);
                            $part = preg_replace('/<!--.*?-->/s', ' ', $part);
                            $part = html_entity_decode(wp_strip_all_tags($part), ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
                            $part = preg_replace('/\s+/u', ' ', trim($part));
                            if ($part !== '' && !in_array($part, $plain, true)) $plain[] = $part;
                        }
                        $url = get_permalink($post_id);
                        $details = array();
                        if ($post_type === 'product') {
                            $sku = get_post_meta($post_id, '_sku', true);
                            $price = get_post_meta($post_id, '_price', true);
                            $regular = get_post_meta($post_id, '_regular_price', true);
                            $sale = get_post_meta($post_id, '_sale_price', true);
                            if (function_exists('wc_get_product')) {
                                $product = wc_get_product($post_id);
                                if ($product) {
                                    $price = $product->get_price();
                                    $price_display = $product->get_price_html();
                                    if ($price_display) $details[] = 'قیمت نمایشی: ' . wp_strip_all_tags($price_display);
                                    if ($product->get_stock_status()) $details[] = 'وضعیت موجودی: ' . ($product->is_in_stock() ? 'موجود' : 'ناموجود');
                                }
                            }
                            if ($sku !== '') $details[] = 'شناسه محصول (SKU): ' . sanitize_text_field($sku);
                            if ($price !== '') $details[] = 'قیمت فعلی: ' . sanitize_text_field((string) $price);
                            if ($regular !== '' && $regular !== $price) $details[] = 'قیمت عادی: ' . sanitize_text_field((string) $regular);
                            if ($sale !== '') $details[] = 'قیمت فروش ویژه: ' . sanitize_text_field((string) $sale);
                            $categories = wp_get_post_terms($post_id, 'product_cat', array('fields' => 'names'));
                            if (!is_wp_error($categories) && $categories) $details[] = 'دسته‌بندی: ' . implode('، ', $categories);
                        }
                        // Keep metadata-only products too: price/name questions must still be answerable.
                        $header = "# {$title}\n\n- نوع محتوا: " . ($post_type === 'post' ? 'مقاله' : ($post_type === 'page' ? 'برگه' : 'محصول')) . "\n- Content type: {$post_type}\n- Post ID: {$post_id}\n- URL: {$url}";
                        if ($details) $header .= "\n" . implode("\n", $details);
                        if ($plain || $details || $title !== '') $content_parts[] = $header . "\n\n" . implode("\n", $plain);
                    } catch (\Throwable $e) {
                        $error_count++; error_log('Chat508 Sync Error (post #' . $post_id . '): ' . $e->getMessage());
                    }
                }
                if (count($query->posts) < $batch_size) break;
                $page++; unset($query);
            }
        }
        $new_content = "# مخزن دانش سایت\n\nاین سند شامل محتوای منتشرشده وردپرس است. هر سند شامل عنوان، نوع محتوا، شناسه، نشانی، توضیحات و مشخصات محصول است. از اطلاعات زیر برای پاسخ استفاده کن؛ قیمت را فقط در صورت وجود صریح در سند اعلام کن و هرگز آن را حدس نزن.\n\n" . implode("\n\n---\n\n", $content_parts);
        if (strlen($new_content) > 12000000) {
            return array('success' => false, 'message' => __('Synced content exceeds 12 MB. Reduce the number of published items or sync selected content.', '508-ai-chat'), 'total_posts' => $total_posts, 'error_count' => $error_count);
        }
        $this->synced_content = $new_content;
        $this->synced_last_run = time();
        update_option('chat508_synced_knowledge', $new_content, false);
        update_option('chat508_synced_last_run', $this->synced_last_run, false);
        update_option('chat508_synced_items_count', count($content_parts), false);
        // Invalidate retrieval cache after a successful sync.
        delete_transient('chat508_kb_documents_' . md5($new_content));
        $this->settings['synced_content'] = '';
        $this->settings['synced_last_run'] = $this->synced_last_run;
        update_option('chat508_settings', $this->settings);
        $this->knowledge_base = (string) ($this->settings['knowledge_base'] ?? '');
        return array('success' => true, 'message' => sprintf(__('Content synced successfully at %s', '508-ai-chat'), current_time('Y-m-d H:i:s')), 'content_length' => strlen($this->synced_content), 'total_posts' => count($content_parts), 'error_count' => $error_count);
    }

    /**
     * Get sync status information
     */
    public function get_sync_status() {
        return array(
            'enabled' => $this->settings['sync_content_enabled'] ?? false,
            'last_run' => (int) get_option('chat508_synced_last_run', $this->synced_last_run),
            'last_run_formatted' => $this->synced_last_run ? date_i18n('Y-m-d H:i:s', $this->synced_last_run) : __('Never', '508-ai-chat'),
            'content_length' => strlen((string) get_option('chat508_synced_knowledge', $this->synced_content)),
            'has_content' => !empty(get_option('chat508_synced_knowledge', $this->synced_content)),
            'post_types' => array('post', 'page', 'product'),
        );
    }

    /**
     * Smart search: find only the relevant paragraphs for a query
     *
     * @param string $query The user's question
     * @param int $max_paragraphs Maximum number of paragraphs to return
     * @return string Relevant paragraphs joined together
     */
    public function smart_search($query, $max_paragraphs = 5, $source_content = null) {
        $content = $source_content === null ? $this->get_effective_content() : (string) $source_content;
        if (trim($content) === '' || trim($query) === '') return '';

        // Cache document splitting between searches. Each post/product is a single retrieval unit.
        $cache_key = 'chat508_kb_documents_' . md5($content);
        $documents = get_transient($cache_key);
        if (!is_array($documents)) {
            $blocks = preg_split('/\n\s*---\s*\n/', $content);
            $documents = array();
            foreach ($blocks as $block) {
                $block = trim($block);
                if ($block !== '') $documents[] = $block;
            }
            set_transient($cache_key, $documents, DAY_IN_SECONDS);
        }
        $query_normalized = $this->normalize_search_text($query);
        $query_words = $this->get_query_keywords($query_normalized);
        if (!$query_words) return '';
        $scored = array();
        foreach ($documents as $index => $doc) {
            $normalized_doc = $this->normalize_search_text($doc);
            $score = 0;
            // Exact product/page title match is intentionally weighted very heavily.
            $title = '';
            if (preg_match('/^#\s*(.+)$/m', $doc, $match)) $title = $this->normalize_search_text($match[1]);
            if ($title !== '' && mb_strpos($query_normalized, $title, 0, 'UTF-8') !== false) $score += 100;
            if ($title !== '' && mb_strpos($title, $query_normalized, 0, 'UTF-8') !== false) $score += 90;
            $matched = 0;
            foreach ($query_words as $word) {
                if (mb_strpos($normalized_doc, $word, 0, 'UTF-8') !== false) {
                    $score += 4;
                    $matched++;
                    if ($title !== '' && mb_strpos($title, $word, 0, 'UTF-8') !== false) $score += 12;
                }
            }
            if ($matched >= 2) $score += $matched * 3;
            if ($score > 0) $scored[] = array('index' => $index, 'score' => $score, 'text' => $doc);
        }
        if (!$scored) return '';
        usort($scored, function($a, $b) { return $b['score'] <=> $a['score']; });
        $limit = max(1, min(10, (int) $max_paragraphs));
        $selected = array_slice($scored, 0, $limit);
        // Avoid sending multiple near-identical documents; retain rank order for relevance.
        $result = array(); $seen = array();
        foreach ($selected as $item) {
            $key = md5(mb_substr($item['text'], 0, 500, 'UTF-8'));
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $result[] = $item['text'];
        }
        return implode("\n\n---\n\n", $result);
    }

    private function normalize_search_text($text) {
        $text = mb_strtolower((string) $text, 'UTF-8');
        $text = str_replace(array('ي','ك','ۀ','ة','أ','إ','ؤ','ئ','ـ'), array('ی','ک','ه','ه','ا','ا','و','ی',''), $text);
        $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $text);
        $text = str_replace(array('سانلایت', 'سان‌لایت', 'والواشر', 'وال‌واشر'), array('سان لایت', 'سان لایت', 'وال واشر', 'وال واشر'), $text);
        $text = str_replace(array(',', '٬'), '', $text);
        return preg_replace('/\s+/u', ' ', trim($text));
    }

    /**
     * Split content into paragraphs
     */
    private function split_into_paragraphs($content) {
        $blocks = preg_split('/\n\s*\n/', $content);
        $paragraphs = array();
        foreach ($blocks as $block) {
            $trimmed = trim($block);
            if (!empty($trimmed) && strlen($trimmed) > 20) {
                $paragraphs[] = $trimmed;
            }
        }
        return $paragraphs;
    }

    /**
     * Extract meaningful keywords from a query
     */
    private function get_query_keywords($query) {
        $stop_words = array(
            'یک', 'یکی', 'این', 'آن', 'اینها', 'کدام', 'چه', 'که', 'است', 'بودن',
            'از', 'با', 'روی', 'در', 'نه', 'برای', 'به', 'تا', 'و', 'یا', 'اما',
            'هم', 'نه', 'اگر', 'که', 'را', 'من', 'شما', 'ما', 'آنها', 'منظور',
            'به', 'از', 'روی', 'با', 'بدون', 'درباره', 'کدام', 'چرا', 'کجا',
            'کِی', 'چگونه', 'چند', 'چه', 'کی', 'ها', 'های', 'این', 'اون',
        );

        $query = $this->normalize_search_text($query);
        $words = preg_split('/[\s\p{P}]+/u', $query, -1, PREG_SPLIT_NO_EMPTY);

        $keywords = array();
        foreach ($words as $word) {
            $word = trim($word);
            if (mb_strlen($word, 'UTF-8') < 2) continue;
            if (in_array($word, $stop_words, true)) continue;
            if (is_numeric($word)) continue;
            $keywords[] = $word;
        }

        return $keywords;
    }

    /**
     * Score a paragraph based on keyword relevance
     */
    private function score_paragraph($paragraph, $query_keywords) {
        if (empty($query_keywords)) {
            return 1;
        }

        $lower_para = mb_strtolower($paragraph, 'UTF-8');
        $lower_para = str_replace(array('ي', 'ك', 'ۀ', 'ة'), array('ی', 'ک', 'ه', 'ه'), $lower_para);
        $score = 0;

        foreach ($query_keywords as $keyword) {
            $count = mb_substr_count($lower_para, $keyword, 'UTF-8');
            if ($count > 0) {
                $score += ($count * 3);

                $words = preg_split('/[\s\p{P}]+/u', $lower_para, -1, PREG_SPLIT_NO_EMPTY);
                if (in_array($keyword, $words, true)) {
                    $score += 5;
                }
            }
        }

        $title_match = false;
        foreach ($query_keywords as $keyword) {
            if (mb_strpos($lower_para, $keyword, 0, 'UTF-8') === 0) {
                $title_match = true;
                break;
            }
        }
        if ($title_match) {
            $score += 10;
        }

        $unique_keywords_in_para = 0;
        $matched_keywords = array();
        foreach ($query_keywords as $keyword) {
            if (mb_strpos($lower_para, $keyword, 0, 'UTF-8') !== false) {
                $matched_keywords[] = $keyword;
            }
        }
        $unique_keywords_in_para = count(array_unique($matched_keywords));
        if ($unique_keywords_in_para >= 3) {
            $score += 15;
        } elseif ($unique_keywords_in_para >= 2) {
            $score += 8;
        }

        return $score;
    }

    /**
     * Build system prompt with knowledge base (using smart search)
     */
    public function build_system_prompt($base_prompt = '', $user_query = '') {
        $system_prompt = $base_prompt ?: ($this->settings['system_prompt'] ?? 'You are a helpful assistant.');
        $restrict = !empty($this->settings['restrict_to_knowledge']);
        $sync_enabled = !empty($this->settings['sync_content_enabled']);
        $manual = trim((string) $this->knowledge_base);
        $synced = $sync_enabled ? trim((string) $this->synced_content) : '';
        $fallback_message = $this->settings['fallback_message'] ?? "I'm sorry, I don't have enough information to answer that question.";

        // Retrieval must work independently of the strict-restriction checkbox.
        // Manual knowledge is searched first, then synced WordPress documents.
        $max_items = max(1, min(10, (int) ($this->settings['smart_search_paragraphs'] ?? 5)));
        $manual_matches = '';
        $synced_matches = '';
        if (trim((string) $user_query) !== '') {
            if ($manual !== '') $manual_matches = $this->smart_search($user_query, $max_items, $manual);
            if ($synced !== '') $synced_matches = $this->smart_search($user_query, $max_items, $synced);
        }

        $sections = array();
        if ($manual_matches !== '') $sections[] = "=== PRIORITY 1: MANUAL KNOWLEDGE BASE ===\n" . $manual_matches;
        if ($synced_matches !== '') $sections[] = "=== PRIORITY 2: SYNCED WORDPRESS CONTENT ===\n" . $synced_matches;
        $relevant_content = implode("\n\n---\n\n", $sections);

        if ($relevant_content === '') {
            if ($restrict) {
                return $system_prompt . "\n\nSTRICT KNOWLEDGE-ONLY MODE: No relevant information was found in either the manually entered knowledge base or synced WordPress content. Do not guess or use general knowledge. Reply briefly and exactly with: \"" . $fallback_message . "\"";
            }
            // If restriction is off, preserve normal assistant behavior when retrieval has no match.
            return $system_prompt;
        }

        $rules = "\n\nRELEVANT SITE KNOWLEDGE (use this before any general knowledge):\n\n" . $relevant_content .
            "\n\nRESPONSE RULES:\n" .
            "1. First consult PRIORITY 1 manual knowledge, then use PRIORITY 2 synced WordPress content to add details or confirm facts.\n" .
            "2. Combine the relevant facts into one concise, clear answer for the user; do not dump the source text.\n" .
            "3. For product price, availability, SKU, specifications, and other site-specific facts, rely only on explicit facts in the supplied site knowledge. Never invent or estimate missing values.\n" .
            "4. If the answer is not supported by the supplied knowledge, " . ($restrict ? "reply exactly with: \"" . $fallback_message . "\". Do not use general knowledge." : "say clearly that the site's information does not specify it; do not invent site-specific facts.") . "\n" .
            "5. Keep the final answer brief and directly address the user's question.";

        return $system_prompt . $rules;
    }

    /**
     * Validate if answer is based on knowledge base
     */
    public function validate_answer($answer) {
        if (!$this->is_active()) {
            return true;
        }

        return !empty($answer);
    }
}