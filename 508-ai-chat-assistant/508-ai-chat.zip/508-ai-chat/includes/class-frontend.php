<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_Frontend {
    private $settings;
    
    public function __construct() {
        $this->settings = get_option('chat508_settings', array());
        add_action('wp_footer', array($this, 'render_chat_widget'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function enqueue_scripts() {
        $options = get_option('chat508_settings', array());
        $theme = $options['theme'] ?? 'light';
        
        // 1. Enqueue main styles
        wp_enqueue_style('chat508-frontend', CHAT508_PLUGIN_URL . 'assets/css/chat.css', array(), CHAT508_VERSION);
        
        // 2. Inject Custom CSS dynamically
        $custom_css = $options['custom_css'] ?? '';
        if (!empty($custom_css)) {
            wp_add_inline_style('chat508-frontend', $custom_css);
            wp_add_inline_style('chat508-responsive', $custom_css);
        }
        
        wp_enqueue_script('chat508-frontend', CHAT508_PLUGIN_URL . 'assets/js/chat.js', array('jquery'), CHAT508_VERSION, true);
        
        // 3. Pass config to JS
        wp_localize_script('chat508-frontend', 'chat508Config', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'resturl' => rest_url('chat508/v1/chat'),
            'nonce' => wp_create_nonce('wp_rest'),
            'theme' => $options['theme'] ?? 'light',
            'buttonPosition' => $options['button_position'] ?? 'bottom-right',
            'primaryColor' => $options['primary_color'] ?? '#10a37f',
            'buttonIconType' => $options['button_icon_type'] ?? 'default',
            'customButtonIcon' => $options['custom_icon_url'] ?? '',
            'enableSound' => isset($options['enable_sound']) && $options['enable_sound'],
            'enableTypingIndicator' => isset($options['enable_typing_indicator']) ? $options['enable_typing_indicator'] : true,
            'customErrorMessage' => $options['custom_error_message'] ?? 'متأسفیم، به دلیل ترافیک بالای سرور موقتاً قادر به پاسخگویی نیستیم. لطفاً چند لحظه دیگر تلاش کنید.',
            'translations' => json_decode($options['translations_json'] ?? $this->get_default_translations_json(), true),
            'chatLanguage' => $options['chat_language'] ?? 'fa'
        ));
    }
    
    public function render_chat_widget() {
        include CHAT508_PLUGIN_DIR . 'templates/chat-widget.php';
    }
}