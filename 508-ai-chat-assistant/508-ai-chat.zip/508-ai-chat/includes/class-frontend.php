<?php
namespace Chat508;

if (!defined('ABSPATH')) exit;

class Chat508_Frontend {
    private $settings;
    
    public function __construct() {
        $this->settings = get_option('chat508_settings', array());
        add_action('wp_footer', array($this, 'render_global_widget'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('chat508_chat', array($this, 'shortcode_widget'));
    }
    
    public function enqueue_scripts() {
        $options = get_option('chat508_settings', array());
        $mode = $options['chat_display_mode'] ?? 'global';
        $post = get_post();
        $has_shortcode = $post && has_shortcode($post->post_content, 'chat508_chat');
        if ($mode !== 'global' && !$has_shortcode) return;
        $theme = $options['theme'] ?? 'light';
        
        // 1. Enqueue main styles
        wp_enqueue_style('chat508-frontend', CHAT508_PLUGIN_URL . 'assets/css/chat.css', array(), CHAT508_VERSION);
        
        // 2. Inject Custom CSS dynamically
        $custom_css = $options['custom_css'] ?? '';
        if (!empty($custom_css)) {
            wp_add_inline_style('chat508-frontend', $custom_css);
            wp_add_inline_style('chat508-responsive', $custom_css);
        }
        
        wp_enqueue_script('chat508-frontend', CHAT508_PLUGIN_URL . 'assets/js/chat.js', array('jquery'), CHAT508_VERSION, true);
        
        // 3. Pass config to JS
        wp_localize_script('chat508-frontend', 'chat508Config', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'resturl' => rest_url('chat508/v1/chat'),
            'nonce' => wp_create_nonce('wp_rest'),
            'theme' => $options['theme'] ?? 'light',
            'buttonPosition' => $options['button_position'] ?? 'bottom-right',
            'primaryColor' => $options['primary_color'] ?? '#10a37f',
            'buttonIconType' => $options['button_icon_type'] ?? 'default',
            'customButtonIcon' => $options['custom_icon_url'] ?? '',
            'enableSound' => isset($options['enable_sound']) && $options['enable_sound'],
            'enableTypingIndicator' => isset($options['enable_typing_indicator']) ? $options['enable_typing_indicator'] : true,
            'customErrorMessage' => $options['custom_error_message'] ?? 'متأسفیم، به دلیل ترافیک بالای سرور موقتاً قادر به پاسخگویی نیستیم. لطفاً چند لحظه دیگر تلاش کنید.',
            'translations' => $this->get_effective_translations($options),
            'chatLanguage' => $options['chat_language'] ?? 'fa'
        ));
    }
    
    private function get_effective_translations($options) {
        $defaults = array(
            'fa' => array('header_title'=>'هر سوالی داری بپرس','header_status'=>'آنلاین هستم','input_placeholder'=>'پیام خود را بنویسید...','footer_text'=>'قدرت گرفته از هوش مصنوعی','welcome_message'=>'سلام! 🤖✨ من دستیار هوش مصنوعی آنامدار هستم. هر سوالی درباره خدمات ما دارید، از من بپرسید.'),
            'en' => array('header_title'=>'Ask me anything','header_status'=>'Online','input_placeholder'=>'Type your message...','footer_text'=>'Powered by AI','welcome_message'=>'Hello! 🤖✨ I am your AI assistant. Ask me anything about our services.'),
            'de' => array('header_title'=>'Stelle deine Frage','header_status'=>'Online','input_placeholder'=>'Nachricht schreiben...','footer_text'=>'Unterstützt durch KI','welcome_message'=>'Hallo! 🤖✨ Ich bin dein KI-Assistent. Frage mich alles über unsere Leistungen.'),
            'fr' => array('header_title'=>'Posez votre question','header_status'=>'En ligne','input_placeholder'=>'Écrivez votre message...','footer_text'=>'Propulsé par l’IA','welcome_message'=>'Bonjour ! 🤖✨ Je suis votre assistant IA. Posez-moi vos questions sur nos services.'),
            'es' => array('header_title'=>'Haz tu pregunta','header_status'=>'En línea','input_placeholder'=>'Escribe tu mensaje...','footer_text'=>'Con tecnología de IA','welcome_message'=>'¡Hola! 🤖✨ Soy tu asistente de IA. Pregúntame sobre nuestros servicios.'),
            'ar' => array('header_title'=>'اسأل ما تريد','header_status'=>'متصل','input_placeholder'=>'اكتب رسالتك...','footer_text'=>'مدعوم بالذكاء الاصطناعي','welcome_message'=>'مرحبًا! 🤖✨ أنا مساعدك الذكي. اسألني عن خدماتنا.')
        );
        $legacy = json_decode($options['translations_json'] ?? '', true);
        if (!is_array($legacy)) $legacy = array();
        $stored = isset($options['chat_ui_texts']) && is_array($options['chat_ui_texts']) ? $options['chat_ui_texts'] : array();
        $result = array();
        foreach ($defaults as $lang => $fields) {
            $result[$lang] = array_merge($fields, isset($legacy[$lang]) && is_array($legacy[$lang]) ? $legacy[$lang] : array(), isset($stored[$lang]) && is_array($stored[$lang]) ? $stored[$lang] : array());
        }
        return $result;
    }

    public function render_global_widget() {
        $options = get_option('chat508_settings', array());
        if (($options['chat_display_mode'] ?? 'global') !== 'global') return;
        $this->render_chat_widget();
    }

    public function shortcode_widget($atts = array()) {
        if (is_admin()) return '';
        $options = get_option('chat508_settings', array());
        if (($options['chat_display_mode'] ?? 'global') !== 'shortcode') return '';
        ob_start(); $this->render_chat_widget(); return ob_get_clean();
    }

    public function render_chat_widget() {
        $this->settings = get_option('chat508_settings', array());
        include CHAT508_PLUGIN_DIR . 'templates/chat-widget.php';
    }
}