/**
 * 508 AI Chat - Frontend JavaScript
 * Modern, modular, and accessible chat interface
 */

(function($) {
    'use strict';
    
    class Chat508 {
        constructor() {
            this.isOpen = false;
            this.conversation = [];
            this.isLoading = false;
            this.typingIndicator = null;
            this.currentLang = 'fa';
            this.translations = {};
            this.init();
        }
        
        init() {
            this.cacheElements();
            this.loadTranslations();
            this.applyTranslations();
            this.bindEvents();
            this.applyConfig();
            this.loadConversation();
        }
        
        cacheElements() {
            this.widget = $('#chat508-widget');
            this.toggleBtn = $('#chat508-toggle');
            this.popup = $('#chat508-popup');
            this.messages = $('#chat508-messages');
            this.input = $('#chat508-input');
            this.form = $('#chat508-form');
            this.sendBtn = $('#chat508-send');
            this.closeBtn = $('.chat508-close-btn');
            this.typingTemplate = document.getElementById('chat508-typing-template');
        }
        
        bindEvents() {
            this.toggleBtn.on('click', () => this.toggle());
            this.closeBtn.on('click', () => this.close());
            this.form.on('submit', (e) => {
                e.preventDefault();
                this.sendMessage();
            });
            
            this.input.on('keypress', (e) => {
                if (e.which === 13 && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            // Close on outside click
            $(document).on('click', (e) => {
                if (this.isOpen && !$(e.target).closest('#chat508-widget').length) {
                    this.close();
                }
            });
            
            // Handle escape key
            $(document).on('keydown', (e) => {
                if (e.key === 'Escape' && this.isOpen) {
                    this.close();
                }
            });
            
            // Handle window resize
            let resizeTimer;
            $(window).on('resize', () => {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(() => {
                    this.handleResize();
                }, 250);
            });
        }
        
        applyConfig() {
            const config = window.chat508Config || {};
            
            // Apply theme
            if (config.theme) {
                this.widget.addClass('chat508-theme-' + config.theme);
            }
            
            // Apply primary color
            if (config.primaryColor) {
                document.documentElement.style.setProperty('--chat508-primary', config.primaryColor);
            }
            
            // Apply button position
            if (config.buttonPosition) {
                this.widget.removeClass('chat508-position-bottom-right chat508-position-bottom-left')
                          .addClass('chat508-position-' + config.buttonPosition);
            }
        }
        
        toggle() {
            this.isOpen ? this.close() : this.open();
        }
        
        open() {
            this.isOpen = true;
            this.toggleBtn.attr('aria-expanded', 'true');
            this.popup.attr('aria-hidden', 'false');
            
            // Prevent background scrolling on mobile
            if (window.innerWidth <= 480) {
                $('body').addClass('chat508-chat-open');
            }
            
            // Focus input after animation
            setTimeout(() => {
                this.input.focus();
                this.scrollToBottom();
            }, 300);
            
            // Announce to screen readers
            this.announceToScreenReader('Chat window opened');
        }
        
        close() {
            this.isOpen = false;
            this.toggleBtn.attr('aria-expanded', 'false');
            this.popup.attr('aria-hidden', 'true');
            
            // Re-enable background scrolling
            $('body').removeClass('chat508-chat-open');
            
            // Focus toggle button
            this.toggleBtn.focus();
            
            // Announce to screen readers
            this.announceToScreenReader('Chat window closed');
        }
        
        async sendMessage() {
            const message = this.input.val().trim();
            if (!message || this.isLoading) return;
            
            this.addMessage(message, 'user');
            this.conversation.push({ role: 'user', content: message });
            
            this.input.val('');
            this.input.prop('disabled', true);
            this.sendBtn.prop('disabled', true);
            this.isLoading = true;
            
            if (chat508Config.enableTypingIndicator) {
                this.showTypingIndicator();
            }
            
            try {
                const response = await fetch(chat508Config.resturl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': chat508Config.nonce
                    },
                    body: JSON.stringify({
                        message: message,
                        conversation: this.conversation
                    })
                });
                
                const data = await response.json();
                this.hideTypingIndicator();
                
                if (data.success) {
                    this.addMessage(data.message, 'bot');
                    this.conversation.push({ role: 'assistant', content: data.message });
                    this.saveConversation();
                    
                    if (chat508Config.enableSound) {
                        this.playNotificationSound();
                    }
                } else {
                    // >>> اینجا خطای اصلی را نادیده می‌گیریم و فقط پیام سفارشی را نشان می‌دهیم <<<
                    const customMsg = (chat508Config && chat508Config.customErrorMessage) 
                        ? chat508Config.customErrorMessage 
                        : "متأسفیم، به دلیل ترافیک بالای سرور موقتاً قادر به پاسخگویی نیستیم. لطفاً چند لحظه دیگر تلاش کنید.";
                    
                    this.addErrorMessage(customMsg);
                    
                    // خطای واقعی را فقط در کنسول مرورگر برای دیباگ نگه می‌داریم
                    console.warn('Chat508 Hidden API Error:', data.error); 
                }
            } catch (error) {
                this.hideTypingIndicator();
                
                // >>> در صورت قطع اینترنت هم فقط پیام سفارشی نمایش داده شود <<<
                const customMsg = (chat508Config && chat508Config.customErrorMessage) 
                    ? chat508Config.customErrorMessage 
                    : "متأسفیم، به دلیل ترافیک بالای سرور موقتاً قادر به پاسخگویی نیستیم. لطفاً چند لحظه دیگر تلاش کنید.";
                
                this.addErrorMessage(customMsg);
                console.error('Chat508 Network Error:', error);
            }
            
            this.input.prop('disabled', false);
            this.sendBtn.prop('disabled', false);
            this.isLoading = false;
            this.input.focus();
        }
        
        loadTranslations() {
            const config = window.chat508Config || {};
            this.translations = config.translations || {};
            this.currentLang = config.chatLanguage || 'fa';
            if (!this.translations[this.currentLang]) {
                this.currentLang = 'fa';
            }
            // if (this.currentLang === 'fa' || this.currentLang === 'ar') {
            //     document.querySelector('.chat508-widget').style.direction = 'rtl';
            // } else {
            //     document.querySelector('.chat508-widget').style.direction = 'ltr';
            // }
        }
    
        applyTranslations() {
            const t = this.translations[this.currentLang];
            if (!t) return;
            
            // بروزرسانی المان‌های ثابت چت
            const headerTitle = document.querySelector('.chat508-header-text h3');
            const headerStatus = document.querySelector('.chat508-status');
            const inputPlaceholder = document.querySelector('.chat508-input');
            const footerText = document.querySelector('.chat508-footer span');
            const welcomeMsg = document.querySelector('.chat508-message-bot .chat508-message-text');
        
            if (headerTitle) headerTitle.textContent = t.header_title;
            if (headerStatus) headerStatus.textContent = t.header_status;
            if (inputPlaceholder) inputPlaceholder.placeholder = t.input_placeholder;
            if (footerText) footerText.textContent = t.footer_text;
            
            // پیام خوش‌آمدگویی اولیه را هم آپدیت می‌کنیم
            if (welcomeMsg && this.conversation.length === 0) {
                welcomeMsg.textContent = t.welcome_message;
            }
        }
        
        addMessage(text, sender) {
            const time = new Date().toLocaleTimeString('en-US', { 
                hour: 'numeric', 
                minute: '2-digit',
                hour12: true 
            });
            
            // برای ربات: HTML را رندر کن (با sanitize برای امنیت)
            // برای کاربر: فقط متن ساده (جلوگیری از XSS)
            const messageContent = sender === 'bot' 
                ? this.sanitizeHtml(text) 
                : this.escapeHtml(text);
            
            const messageHtml = `
                <div class="chat508-message chat508-message-${sender}" role="article" aria-label="${sender === 'user' ? 'Your message' : 'Assistant message'}">
                    ${sender === 'bot' ? `
                    <div class="chat508-message-avatar" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor"/>
                        </svg>
                    </div>
                    ` : ''}
                    <div class="chat508-message-content">
                        <div class="chat508-message-text">${messageContent}</div>
                        <span class="chat508-message-time">${time}</span>
                    </div>
                </div>
            `;
            
            this.messages.append(messageHtml);
            this.scrollToBottom();
        }
        
        sanitizeHtml(html) {
            if (!html) return '';

            // ابتدا لینک‌های Markdown را به لینک امن تبدیل می‌کنیم و موقتاً
            // از پردازش دوباره URL داخل لینک جلوگیری می‌کنیم.
            const markdownLinks = [];
            html = String(html).replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, (match, label, url) => {
                // فقط لینک‌های HTTP/HTTPS مجاز هستند.
                if (!/^https?:\/\//i.test(url)) return match;
                const safeLabel = this.escapeHtml(label);
                const safeUrl = this.escapeHtml(url).replace(/`/g, '&#96;');
                const token = `CHAT508MARKDOWNLINKTOKEN${markdownLinks.length}END`;
                markdownLinks.push(`<a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${safeLabel}</a>`);
                return token;
            });
            
            // تبدیل لینک‌های ساده به تگ <a>؛ لینک‌های Markdown بالا محافظت شده‌اند.
            html = html.replace(/(https?:\/\/[^\s<]+|www\.[^\s<]+)/g, function(url) {
                // علائم رایج انتهای جمله را از آدرس جدا می‌کنیم.
                const trailing = (url.match(/[.,!?،؛)\]]+$/) || [''])[0];
                const cleanUrl = trailing ? url.slice(0, -trailing.length) : url;
                if (!cleanUrl) return url;
                const href = cleanUrl.startsWith('www.') ? 'https://' + cleanUrl : cleanUrl;
                return `<a href="${href}" target="_blank" rel="noopener noreferrer">${cleanUrl}</a>${trailing}`;
            });
            
            // تبدیل **text** به <strong>text</strong>
            html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
            
            // تبدیل *text* به <em>text</em>
            html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
            
            // تبدیل `text` به <code>text</code>
            html = html.replace(/`(.+?)`/g, '<code>$1</code>');
            
            // تبدیل خطوط جدید به <br>
            html = html.replace(/\n/g, '<br>');
            
            // حذف تگ‌های غیرمجاز (جلوگیری از XSS)
            html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
            html = html.replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '');
            html = html.replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '');
            html = html.replace(/<embed\b[^<]*(?:(?!<\/embed>)<[^<]*)*<\/embed>/gi, '');
            html = html.replace(/<form\b[^<]*(?:(?!<\/form>)<[^<]*)*<\/form>/gi, '');
            
            // حذف event handler ها مثل onclick, onerror و غیره
            html = html.replace(/\s+on\w+\s*=\s*["'][^"']*["']/gi, '');
            html = html.replace(/\s+on\w+\s*=\s*[^\s>]*/gi, '');
            
            // حذف javascript: و data: در href
            html = html.replace(/href\s*=\s*["']javascript:[^"']*["']/gi, 'href="#"');
            html = html.replace(/href\s*=\s*["']data:[^"']*["']/gi, 'href="#"');

            // بازگرداندن لینک‌های Markdown بعد از تبدیل URLهای ساده تا لینک تو در تو نشود.
            markdownLinks.forEach((link, index) => {
                html = html.replace(`CHAT508MARKDOWNLINKTOKEN${index}END`, link);
            });
            
            return html;
        }
        
        addErrorMessage(text) {
            const errorHtml = `
                <div class="chat508-error-message" role="alert">
                    ${this.escapeHtml(text)}
                </div>
            `;
            
            this.messages.append(errorHtml);
            this.scrollToBottom();
        }
        
        showTypingIndicator() {
            if (this.typingTemplate) {
                const typingHtml = this.typingTemplate.innerHTML;
                this.messages.append(typingHtml);
                this.typingIndicator = this.messages.find('.chat508-typing').last();
                this.scrollToBottom();
            }
        }
        
        hideTypingIndicator() {
            if (this.typingIndicator) {
                this.typingIndicator.remove();
                this.typingIndicator = null;
            }
        }
        
        scrollToBottom() {
            this.messages.scrollTop(this.messages[0].scrollHeight);
        }
        
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        playNotificationSound() {
            // Simple beep sound using Web Audio API
            try {
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.frequency.value = 800;
                oscillator.type = 'sine';
                
                gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
                
                oscillator.start(audioContext.currentTime);
                oscillator.stop(audioContext.currentTime + 0.1);
            } catch (e) {
                console.error('Sound play failed:', e);
            }
        }
        
        saveConversation() {
            try {
                localStorage.setItem('chat508_conversation', JSON.stringify(this.conversation));
            } catch (e) {
                console.error('Failed to save conversation:', e);
            }
        }
        
        loadConversation() {
            try {
                const saved = localStorage.getItem('chat508_conversation');
                if (saved) {
                    this.conversation = JSON.parse(saved);
                    // Reload messages from conversation
                    this.conversation.forEach(msg => {
                        if (msg.role === 'user') {
                            this.addMessage(msg.content, 'user');
                        } else if (msg.role === 'assistant') {
                            this.addMessage(msg.content, 'bot');
                        }
                    });
                }
            } catch (e) {
                console.error('Failed to load conversation:', e);
            }
        }
        
        handleResize() {
            // Adjust for mobile/desktop transitions
            if (window.innerWidth <= 480 && this.isOpen) {
                $('body').addClass('chat508-chat-open');
            } else {
                $('body').removeClass('chat508-chat-open');
            }
        }
        
        announceToScreenReader(message) {
            const announcement = $('<div>', {
                'aria-live': 'polite',
                'aria-atomic': 'true',
                'class': 'screen-reader-only',
                'css': {
                    'position': 'absolute',
                    'width': '1px',
                    'height': '1px',
                    'padding': '0',
                    'margin': '-1px',
                    'overflow': 'hidden',
                    'clip': 'rect(0,0,0,0)',
                    'border': '0'
                }
            }).text(message);
            
            $('body').append(announcement);
            setTimeout(() => announcement.remove(), 1000);
        }
        
       
    }
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        new Chat508();
    });
    
})(jQuery);