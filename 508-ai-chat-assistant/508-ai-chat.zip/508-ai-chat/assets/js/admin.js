/**
 * 508 AI Chat - Admin JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Show only the selected language's editable chat texts.
        function showChatLanguageFields() {
            var lang = $('#chat508-ui-language').val() || 'fa';
            $('.chat508-ui-language-fields').hide().filter('[data-language="' + lang + '"]').show();
        }
        $('#chat508-ui-language').on('change', showChatLanguageFields);
        showChatLanguageFields();

        // Only submit the model field belonging to the selected provider.
        $('#chat508-settings-form').on('submit', function() {
            $('.provider-settings').find('[name="chat508_settings[selected_model]"]').prop('disabled', true);
            var provider = $('#api-provider-select').val();
            var selector = provider === 'add_new_custom' ? '#add-new-custom-settings' :
                (provider.indexOf('custom_') === 0 ? '#custom-' + provider.replace('custom_', '') + '-settings' : '#' + provider + '-settings');
            $(selector).find('[name="chat508_settings[selected_model]"]').prop('disabled', false);
        });

        
        // ============================================
        // Tab Navigation
        // ============================================
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            const targetTab = $(this).data('tab');
            
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            $('.chat508-tab-content').removeClass('active');
            $('#tab-' + targetTab).addClass('active');
            
            localStorage.setItem('chat508_active_tab', targetTab);
        });
        
        // Restore active tab
        const activeTab = localStorage.getItem('chat508_active_tab') || 'api';
        $('.nav-tab[data-tab="' + activeTab + '"]').trigger('click');
        
        // ============================================
        // Auto-update model when provider changes
        // ============================================
        const providerModels = {
            'cerebras': 'gpt-oss-120b',
            'groq': 'llama-3.1-8b-instant',
            'openai': 'gpt-4o'
        };
        
        $('#api-provider-select').on('change', function() {
            const provider = $(this).val();
            
            // Only auto-update for built-in providers (not custom)
            if (providerModels[provider]) {
                // Check if there's a model select in the visible provider settings
                const visibleSettings = $('.provider-settings:visible');
                const modelSelect = visibleSettings.find('select[name="chat508_settings[selected_model]"]');
                
                if (modelSelect.length > 0) {
                    modelSelect.val(providerModels[provider]);
                }
            }
            
            showProviderSettings(provider);
        });
        // ============================================
        // Provider Selection - Show/Hide Settings
        // ============================================
        function showProviderSettings(provider) {
            // Hide ALL provider settings first
            $('.provider-settings').hide();
            
            // Show the correct one
            if (provider === 'cerebras') {
                $('#cerebras-settings').show();
            } else if (provider === 'groq') {
                $('#groq-settings').show();
            } else if (provider === 'openai') {
                $('#openai-settings').show();
            } else if (provider === 'google') {
                $('#google-settings').show();
            } else if (provider === 'add_new_custom') {
                $('#add-new-custom-settings').show();
            } else if (provider.startsWith('custom_')) {
                const customId = provider.replace('custom_', '');
                $('#custom-' + customId + '-settings').show();
            }
        }
        
        // Initial state
        const currentProvider = $('#api-provider-select').val();
        showProviderSettings(currentProvider);
        
        // On change
        $('#api-provider-select').on('change', function() {
            showProviderSettings($(this).val());
        });
        
        // ============================================
        // Icon Type Toggle
        // ============================================
        $('#button-icon-type').on('change', function() {
            if ($(this).val() === 'custom') {
                $('#custom-icon-upload-row').show();
            } else {
                $('#custom-icon-upload-row').hide();
            }
        });
        
        // ============================================
        // Media Upload for Custom Icon
        // ============================================
        $('#upload-button-icon').on('click', function(e) {
            e.preventDefault();
            
            const mediaUploader = wp.media({
                title: chat508Admin.strings.selectIcon,
                button: { text: chat508Admin.strings.useIcon },
                library: { type: 'image' },
                multiple: false
            }).open()
            .on('select', function() {
                const attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#button-custom-icon').val(attachment.url);
            });
        });
        
        // ============================================
        // Custom Provider - Save via AJAX
        // ============================================
        $('#save-custom-provider').on('click', function() {
            const name = $('#custom-provider-name').val().trim();
            const baseUrl = $('#custom-provider-base-url').val().trim();
            const apiKey = $('#custom-provider-api-key').val().trim();
            const model = $('#custom-provider-model').val().trim();
            const headers = $('#custom-provider-headers').val().trim();
            const params = $('#custom-provider-params').val().trim();
            
            // Validation
            if (!name || !baseUrl || !apiKey || !model) {
                alert(chat508Admin.strings.fillAllFields);
                return;
            }
            
            if (headers && !isValidJSON(headers)) {
                alert(chat508Admin.strings.invalidJson + ': Headers');
                return;
            }
            
            if (params && !isValidJSON(params)) {
                alert(chat508Admin.strings.invalidJson + ': Parameters');
                return;
            }
            
            $.ajax({
                url: chat508Admin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'chat508_save_custom_provider',
                    nonce: chat508Admin.nonce,
                    name: name,
                    base_url: baseUrl,
                    api_key: apiKey,
                    model: model,
                    headers: headers,
                    params: params
                },
                beforeSend: function() {
                    $('#save-custom-provider').prop('disabled', true).text(chat508Admin.strings.saving);
                },
                success: function(response) {
                    if (response.success) {
                        // Reload to show the new provider in dropdown
                        window.location.reload();
                    } else {
                        alert(response.data.message || chat508Admin.strings.error);
                    }
                },
                error: function() {
                    alert(chat508Admin.strings.error);
                },
                complete: function() {
                    $('#save-custom-provider').prop('disabled', false).text(chat508Admin.strings.saved);
                }
            });
        });
        
        // Cancel custom provider form
        $('#cancel-custom-provider').on('click', function() {
            clearCustomProviderForm();
            // Switch back to previous provider
            const previousProvider = localStorage.getItem('chat508_previous_provider') || 'cerebras';
            $('#api-provider-select').val(previousProvider);
            showProviderSettings(previousProvider);
        });
        
        // Save previous provider before switching to "add new"
        $('#api-provider-select').on('change', function() {
            const val = $(this).val();
            if (val !== 'add_new_custom') {
                localStorage.setItem('chat508_previous_provider', val);
            }
        });
        
        // ============================================
        // Delete Custom Provider
        // ============================================
        $(document).on('click', '.delete-provider', function() {
            if (!confirm(chat508Admin.strings.confirmDelete)) {
                return;
            }
            
            const providerId = $(this).data('provider-id');
            
            $.ajax({
                url: chat508Admin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'chat508_delete_custom_provider',
                    nonce: chat508Admin.nonce,
                    provider_id: providerId
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        alert(response.data.message || chat508Admin.strings.error);
                    }
                },
                error: function() {
                    alert(chat508Admin.strings.error);
                }
            });
        });
        
        // ============================================
        // Language Switcher
        // ============================================
        $(document).on('change', '#chat508-admin-language, #chat508-admin-language-kb', function() {
            const lang = $(this).val();
            const nonce = $(this).data('nonce');
            
            $.ajax({
                url: chat508Admin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'chat508_switch_language',
                    nonce: nonce,
                    language: lang
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        alert(response.data.message || chat508Admin.strings.error);
                    }
                },
                error: function() {
                    alert(chat508Admin.strings.error);
                }
            });
        });

        // ============================================
        // Content Sync
        // ============================================
        $('#chat508-sync-enabled').on('change', function() {
            const isChecked = $(this).is(':checked');
            const syncStatus = $('#chat508-sync-status');
            const syncButton = $('#chat508-sync-button');

            if (isChecked) {
                syncStatus.show();
                syncButton.show();
            } else {
                syncStatus.hide();
                syncButton.hide();
            }
        });

        $('#chat508-sync-button').on('click', function() {
            const $btn = $(this);
            const $loading = $('#chat508-sync-loading');
            const $result = $('#chat508-sync-result');

            $btn.prop('disabled', true);
            $loading.show();
            $result.text('');

            $.ajax({
                url: chat508Admin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'chat508_sync_content',
                    nonce: chat508Admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        const contentLen = response.data.content_length || 0;
                        $result.html('<span style="color: #46b450;">' + response.data.message + ' (' + contentLen.toLocaleString() + ' chars)</span>');
                        $('#chat508-sync-status-content').html(
                            '<span style="background: #46b450; color: #fff; padding: 4px 10px; border-radius: 4px; font-size: 13px;">' +
                            response.data.message +
                            '</span>'
                        );
                        $('#chat508-restore-kb').show();
                        $('#chat508-sync-content-length').text(
                            'Synced content size: ' + contentLen.toLocaleString() + ' characters.'
                        );
                    } else {
                        $result.html('<span style="color: #dc3232;">' + (response.data.message || 'Sync failed') + '</span>');
                    }
                },
                error: function() {
                    $result.html('<span style="color: #dc3232;">Sync request failed</span>');
                },
                complete: function() {
                    $btn.prop('disabled', false);
                    $loading.hide();
                }
            });
        });

        $('#chat508-restore-kb').on('click', function() {
            if (!confirm(chat508Admin.strings.confirmRestore || 'Are you sure you want to restore the knowledge base to manual mode?')) {
                return;
            }

            const $btn = $(this);
            $btn.prop('disabled', true);

            $.ajax({
                url: chat508Admin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'chat508_restore_kb',
                    nonce: chat508Admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $btn.hide();
                        $('#chat508-sync-status-content').html(
                            '<span style="background: #6c757d; color: #fff; padding: 4px 10px; border-radius: 4px; font-size: 13px;">Manual Mode</span>'
                        );
                        $('#chat508-sync-content-length').text('');
                    } else {
                        alert(response.data.message || 'Failed to restore');
                    }
                },
                error: function() {
                    alert('Request failed');
                },
                complete: function() {
                    $btn.prop('disabled', false);
                }
            });
        });

        // ============================================
        // Helper Functions
        // ============================================
        function clearCustomProviderForm() {
            $('#custom-provider-name').val('');
            $('#custom-provider-base-url').val('');
            $('#custom-provider-api-key').val('');
            $('#custom-provider-model').val('');
            $('#custom-provider-headers').val('');
            $('#custom-provider-params').val('');
        }
        
        function isValidJSON(str) {
            try {
                JSON.parse(str);
                return true;
            } catch (e) {
                return false;
            }
        }
        
        // ============================================
        // Sync model selection with provider
        // ============================================
        $(document).on('change', 'select[name="chat508_settings[selected_model]"]', function() {
            const provider = $(this).data('provider');
            const model = $(this).val();
            
            // Store in localStorage for reference
            localStorage.setItem('chat508_model_' + provider, model);
        });
    });
    
})(jQuery);