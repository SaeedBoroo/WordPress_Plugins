<?php
/**
 * Plugin Name: 508 Card2Card Receipt
 * Description: پرداخت کارت‌به‌کارت با نمایش اطلاعات حساب، بارگذاری و فشرده‌سازی فیش، تاریخ شمسی و مشاهده فیش برای مدیر و مشتری؛
 * Version: 1.3.0
 * Author: 508
 * Requires Plugins: woocommerce
 * Text Domain: 508-card2card-receipt
 */
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'C508_Card2Card_Receipt' ) ) {

final class C508_Card2Card_Receipt {

	const VER       = '1.3.0';
	const NONCE     = 'c508_c2c_upload';
	const FOLDER    = '508-card2card-receipt';
	const MAX_MB    = 2;   // حجم نهایی فایل ذخیره‌شده (و سقف PDF)
	const MAX_IN_MB = 5;  // سقف حجم تصویر ورودی، قبل از فشرده‌سازی
	const MAX_PX    = 2000;
	const M_PATH    = '_508_c2c_path';
	const M_NAME    = '_508_c2c_name';
	const M_DATE    = '_508_c2c_date';
	const M_GDATE   = '_508_c2c_gdate';
	const M_MIME    = '_508_c2c_mime';
	const M_DONE    = '_508_c2c_uploaded';

	private static $legacy = array(
		self::M_PATH => '_ana_card2card_receipt_path',
		self::M_NAME => '_ana_card2card_receipt_name',
		self::M_DATE => '_ana_card2card_transfer_date',
		self::M_MIME => '_ana_card2card_receipt_mime',
		self::M_DONE => '_ana_card2card_receipt_uploaded',
	);

	/** فرمت‌های قابل نمایش (فایل‌های ذخیره‌شده) */
	private static $mimes = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf' );

	private static $rendered = array();

	public static function init() {
		register_activation_hook( __FILE__, array( __CLASS__, 'dir' ) );
		add_action( 'before_woocommerce_init', array( __CLASS__, 'hpos' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'boot' ), 20 );
	}

	public static function hpos() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}

	public static function boot() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_filter( 'woocommerce_bacs_process_payment_order_status', function () { return 'on-hold'; } );
		add_filter( 'woocommerce_payment_successful_result', array( __CLASS__, 'result_data' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_c508_c2c_upload', array( __CLASS__, 'ajax_upload' ) );
		add_action( 'wp_ajax_nopriv_c508_c2c_upload', array( __CLASS__, 'ajax_upload' ) );
		add_action( 'woocommerce_order_details_before_order_table', array( __CLASS__, 'render_box' ), 5 );
		add_action( 'wp_footer', array( __CLASS__, 'footer_fallback' ), 25 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'admin_box' ) );
		add_action( 'admin_post_c508_c2c_view', array( __CLASS__, 'view_receipt' ) );
		add_action( 'admin_post_nopriv_c508_c2c_view', array( __CLASS__, 'view_receipt' ) );
		add_action( 'woocommerce_thankyou_bacs', array( __CLASS__, 'hide_default_bacs' ), 1 );
	}

	/* ================= ابزارها ================= */

	private static function meta( $order, $key ) {
		$v = $order->get_meta( $key );
		if ( '' === $v && isset( self::$legacy[ $key ] ) ) {
			$v = $order->get_meta( self::$legacy[ $key ] );
		}
		return $v;
	}

	private static function needs_receipt( $order ) {
		return $order instanceof WC_Order
			&& 'bacs' === $order->get_payment_method()
			&& ! self::meta( $order, self::M_DONE )
			&& $order->has_status( array( 'on-hold', 'pending' ) );
	}

	private static function can_view( $order ) {
		if ( is_user_logged_in() && ( (int) $order->get_user_id() === get_current_user_id() || current_user_can( 'manage_woocommerce' ) ) ) {
			return true;
		}
		$key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		return $key && hash_equals( $order->get_order_key(), $key );
	}

	/** پوشه ذخیره؛ اگر نبود ساخته و ایمن می‌شود */
	public static function dir() {
		$dir = WP_CONTENT_DIR . '/uploads/' . self::FOLDER;
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$files = array(
			'index.php' => "<?php // Silence is golden.\n",
			'.htaccess' => "Options -Indexes\n<FilesMatch \"\\.(php|phtml|phar|pl|py|cgi|sh)$\">\nSetHandler none\n</FilesMatch>\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n",
		);
		foreach ( $files as $name => $body ) {
			if ( is_dir( $dir ) && ! file_exists( $dir . '/' . $name ) ) {
				@file_put_contents( $dir . '/' . $name, $body );
			}
		}
		return $dir;
	}

	/** پوشه فعلی + پوشه‌های نسخه‌های قبلی (فقط برای خواندن) */
	private static function bases() {
		return array_filter( array_map( 'realpath', array(
			self::dir(),
			WP_CONTENT_DIR . '/uploads/card2card-fish',
			trailingslashit( wp_upload_dir()['basedir'] ) . 'card2card-fish',
		) ) );
	}

	private static function latin( $s ) {
		return strtr( (string) $s, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9' ) );
	}

	private static function fa( $s ) {
		return strtr( (string) $s, array( '0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹' ) );
	}

	private static function g2j( $gy, $gm, $gd ) {
		$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
		$gy2   = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
		$days  = 355666 + ( 365 * $gy ) + intdiv( $gy2 + 3, 4 ) - intdiv( $gy2 + 99, 100 ) + intdiv( $gy2 + 399, 400 ) + $gd + $g_d_m[ $gm - 1 ];
		$jy    = -1595 + ( 33 * intdiv( $days, 12053 ) );
		$days %= 12053;
		$jy   += 4 * intdiv( $days, 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$jy  += intdiv( $days - 1, 365 );
			$days = ( $days - 1 ) % 365;
		}
		if ( $days < 186 ) {
			$jm = 1 + intdiv( $days, 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + intdiv( $days - 186, 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}
		return array( $jy, $jm, $jd );
	}

	private static function j2g( $jy, $jm, $jd ) {
		$jy  += 1595;
		$days = -355668 + ( 365 * $jy ) + ( intdiv( $jy, 33 ) * 8 ) + intdiv( ( $jy % 33 ) + 3, 4 ) + $jd + ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );
		$gy   = 400 * intdiv( $days, 146097 );
		$days %= 146097;
		if ( $days > 36524 ) {
			$gy  += 100 * intdiv( --$days, 36524 );
			$days %= 36524;
			if ( $days >= 365 ) {
				$days++;
			}
		}
		$gy   += 4 * intdiv( $days, 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$gy  += intdiv( $days - 1, 365 );
			$days = ( $days - 1 ) % 365;
		}
		$gd  = $days + 1;
		$sal = array( 0, 31, ( ( 0 === $gy % 4 && 0 !== $gy % 100 ) || 0 === $gy % 400 ) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
		for ( $gm = 0; $gm < 13 && $gd > $sal[ $gm ]; $gm++ ) {
			$gd -= $sal[ $gm ];
		}
		return array( $gy, $gm, $gd );
	}

	private static function today_j() {
		list( $y, $m, $d ) = array_map( 'intval', explode( '-', current_time( 'Y-m-d' ) ) );
		return self::g2j( $y, $m, $d );
	}

	private static function display_date( $order ) {
		$d = self::latin( self::meta( $order, self::M_DATE ) );
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $d, $m ) && (int) $m[1] > 1900 ) {
			list( $jy, $jm, $jd ) = self::g2j( (int) $m[1], (int) $m[2], (int) $m[3] );
			$d = sprintf( '%04d/%02d/%02d', $jy, $jm, $jd );
		}
		return self::fa( $d );
	}

	private static function is_pdf( $order ) {
		return 'application/pdf' === self::meta( $order, self::M_MIME );
	}

	private static function view_url( $order ) {
		return add_query_arg(
			array( 'action' => 'c508_c2c_view', 'order_id' => $order->get_id(), 'key' => $order->get_order_key() ),
			admin_url( 'admin-post.php' )
		);
	}

	private static function money( $order ) {
		return html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ), ENT_QUOTES, 'UTF-8' );
	}

	private static function accounts() {
		$out = array();
		foreach ( (array) get_option( 'woocommerce_bacs_accounts', array() ) as $a ) {
			if ( ! is_array( $a ) ) {
				continue;
			}
			$item = array();
			foreach ( array( 'account_name', 'bank_name', 'account_number', 'iban' ) as $k ) {
				if ( ! empty( $a[ $k ] ) ) {
					$item[ $k ] = sanitize_text_field( $a[ $k ] );
				}
			}
			if ( $item ) {
				$out[] = $item;
			}
		}
		return $out;
	}

	private static function fail( $msg, $code = 400 ) {
		wp_send_json_error( array( 'message' => $msg ), $code );
	}

	/* ================= چک‌اوت ================= */

	public static function result_data( $result, $order_id ) {
		$order = wc_get_order( $order_id );
		if ( is_array( $result ) && self::needs_receipt( $order ) ) {
			$result['c508'] = array(
				'id'    => $order->get_id(),
				'key'   => $order->get_order_key(),
				'total' => self::money( $order ),
			);
		}
		return $result;
	}

	public static function hide_default_bacs() {
		$gw = WC()->payment_gateways()->payment_gateways();
		if ( isset( $gw['bacs'] ) ) {
			remove_action( 'woocommerce_thankyou_bacs', array( $gw['bacs'], 'thankyou_page' ) );
		}
	}

	/* ================= استایل و اسکریپت ================= */

	public static function assets() {
		$ok = ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_account_page' ) && is_account_page() ) || isset( $_GET['mersa_order'] );
		if ( ! $ok ) {
			return;
		}
		wp_register_style( 'c508-c2c', false, array(), self::VER );
		wp_enqueue_style( 'c508-c2c' );
		wp_add_inline_style( 'c508-c2c', self::css() );

		$cfg = array(
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( self::NONCE ),
			'today'    => self::today_j(),
			'maxImg'   => self::MAX_IN_MB,
			'maxPdf'   => self::MAX_MB,
			'accounts' => self::accounts(),
			'months'   => array( 'فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند' ),
			's'        => array(
				'title'   => 'پرداخت کارت‌به‌کارت',
				'desc'    => 'مبلغ سفارش را به یکی از حساب‌های زیر واریز کنید و تصویر یا PDF فیش را بارگذاری نمایید.',
				'amount'  => 'مبلغ قابل پرداخت',
				'noAcc'   => 'اطلاعات حساب بانکی در تنظیمات ووکامرس تعریف نشده است.',
				'date'    => 'تاریخ واریز',
				'file'    => 'تصویر یا PDF فیش واریز',
				'drop'    => 'فیش را اینجا رها کنید یا کلیک کنید',
				'types'   => 'JPG، PNG، WebP، HEIC، GIF یا PDF — تصویر تا ۱۰ و PDF تا ۲ مگابایت',
				'submit'  => 'ثبت فیش و تکمیل سفارش',
				'copy'    => 'کپی',
				'copied'  => 'کپی شد ✓',
				'noFile'  => 'لطفاً فایل فیش را انتخاب کنید.',
				'badType' => 'فقط تصویر یا فایل PDF مجاز است.',
				'big'     => 'حجم تصویر نباید بیشتر از ۱۰ مگابایت باشد.',
				'bigPdf'  => 'حجم فایل PDF نباید بیشتر از ۲ مگابایت باشد.',
				'fail'    => 'ثبت فیش ناموفق بود. لطفاً دوباره تلاش کنید.',
				'ok'      => 'فیش با موفقیت ثبت شد',
				'wait'    => 'سفارش شما در حال انجام است…',
				'close'   => 'اگر پنجره را ببندید، سفارش «در انتظار بررسی» می‌ماند و بعداً می‌توانید از پنل کاربری فیش را ثبت کنید. بسته شود؟',
			),
		);

		wp_register_script( 'c508-c2c', false, array( 'jquery' ), self::VER, true );
		wp_enqueue_script( 'c508-c2c' );
		wp_add_inline_script( 'c508-c2c', 'window.C508C2C=' . wp_json_encode( $cfg ) . ';' . self::js() );
	}

	/* ================= پنل کاربری / صفحه تشکر ================= */

	private static function box_html( $order ) {
		if ( 'bacs' !== $order->get_payment_method() ) {
			return '';
		}
		if ( self::meta( $order, self::M_DONE ) ) {
			$url = esc_url( self::view_url( $order ) );
			$pdf = self::is_pdf( $order );
			$th  = $pdf
				? '<a href="' . $url . '" class="c508-thumb c508-pdf" target="_blank" rel="noopener nofollow"><span>📄</span><b>PDF</b></a>'
				: '<a href="' . $url . '" class="c508-thumb" data-full="' . $url . '" rel="nofollow"><img src="' . $url . '" alt="فیش واریز" loading="lazy"></a>';
			return '<div class="c508-wrap c508-done">' . $th
				. '<div class="c508-done-t"><b><i class="c508-ok"></i>فیش کارت‌به‌کارت ثبت شده.</b>'
				. '<span>تاریخ واریز: ' . esc_html( self::display_date( $order ) ) . '</span>'
				. '<small>برای مشاهده، روی ' . ( $pdf ? 'فایل' : 'تصویر' ) . ' فیش کلیک کنید.</small></div></div>';
		}
		if ( self::needs_receipt( $order ) ) {
			$total = self::money( $order );
			return '<div class="c508-wrap c508-cta"><i class="c508-cta-ic"></i>'
				. '<div class="c508-cta-t"><b>در انتظار پرداخت کارت‌به‌کارت</b>'
				. '<span>مبلغ ' . esc_html( $total ) . ' را واریز و فیش را ثبت کنید تا سفارش شما پردازش شود.</span></div>'
				. '<button type="button" class="c508-btn c508-open" data-order="' . esc_attr( $order->get_id() ) . '" data-key="' . esc_attr( $order->get_order_key() ) . '" data-total="' . esc_attr( $total ) . '">پرداخت و ثبت فیش</button></div>';
		}
		return '';
	}

	public static function render_box( $order ) {
		if ( ! $order instanceof WC_Order || isset( self::$rendered[ $order->get_id() ] ) || ! self::can_view( $order ) ) {
			return;
		}
		$html = self::box_html( $order );
		if ( $html ) {
			self::$rendered[ $order->get_id() ] = true;
			echo $html; // phpcs:ignore
		}
	}

	public static function footer_fallback() {
		$id = isset( $_GET['mersa_order'] ) ? absint( $_GET['mersa_order'] ) : 0;
		if ( ! $id || isset( self::$rendered[ $id ] ) ) {
			return;
		}
		$order = wc_get_order( $id );
		if ( ! $order || ! self::can_view( $order ) ) {
			return;
		}
		$html = self::box_html( $order );
		if ( ! $html ) {
			return;
		}
		self::$rendered[ $id ] = true;
		?>
		<script>
		jQuery(function(){
			if (jQuery('.c508-wrap').length) return;
			var t = jQuery('.mersa-order-details,.woocommerce-order-details,.woocommerce-order,.woocommerce-MyAccount-content,.entry-content').first();
			(t.length ? t : jQuery('body')).prepend(<?php echo wp_json_encode( $html ); ?>);
		});
		</script>
		<?php
	}

	/* ================= آپلود ================= */

	public static function ajax_upload() {
		check_ajax_referer( self::NONCE, 'nonce' );

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$key      = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';
		$order    = $order_id ? wc_get_order( $order_id ) : false;

		if ( ! $order || 'bacs' !== $order->get_payment_method() ) {
			self::fail( 'سفارش یافت نشد.', 404 );
		}
		$owner = is_user_logged_in() && (int) $order->get_user_id() === get_current_user_id();
		if ( ! $owner && ! ( $key && hash_equals( $order->get_order_key(), $key ) ) ) {
			self::fail( 'اجازه دسترسی به این سفارش را ندارید.', 403 );
		}
		if ( ! self::needs_receipt( $order ) ) {
			self::fail( 'برای این سفارش قبلاً فیش ثبت شده یا نیازی به فیش ندارد.' );
		}

		// تاریخ شمسی
		$date = self::latin( isset( $_POST['transfer_date'] ) ? sanitize_text_field( wp_unslash( $_POST['transfer_date'] ) ) : '' );
		if ( ! preg_match( '#^(\d{4})/(\d{1,2})/(\d{1,2})$#', $date, $m ) ) {
			self::fail( 'تاریخ واریز معتبر نیست.' );
		}
		$j = array( (int) $m[1], (int) $m[2], (int) $m[3] );
		$g = self::j2g( $j[0], $j[1], $j[2] );
		if ( self::g2j( $g[0], $g[1], $g[2] ) !== $j ) {
			self::fail( 'تاریخ واریز معتبر نیست.' );
		}
		$gdate = sprintf( '%04d-%02d-%02d', $g[0], $g[1], $g[2] );
		if ( $gdate > current_time( 'Y-m-d' ) ) {
			self::fail( 'تاریخ واریز نمی‌تواند بعد از امروز باشد.' );
		}
		$jdate = sprintf( '%04d/%02d/%02d', $j[0], $j[1], $j[2] );

		// فایل
		if ( empty( $_FILES['receipt']['tmp_name'] ) || ! empty( $_FILES['receipt']['error'] ) || ! is_uploaded_file( $_FILES['receipt']['tmp_name'] ) ) {
			self::fail( 'فایلی دریافت نشد.' );
		}
		$f     = $_FILES['receipt'];
		$tmp   = $f['tmp_name'];
		$size  = (int) $f['size'];
		$types = array(
			'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp',
			'gif' => 'image/gif', 'heic' => 'image/heic', 'heif' => 'image/heif', 'pdf' => 'application/pdf',
		);
		$checked = wp_check_filetype_and_ext( $tmp, $f['name'], $types );
		$mime    = $checked['type'] ?? '';
		if ( ! $mime || ! in_array( $mime, $types, true ) || $size <= 0 ) {
			self::fail( 'فقط تصویر (JPG، PNG، WebP، GIF، HEIC) یا فایل PDF مجاز است.' );
		}

		// مسیر و نام: C2C_OrderNum_Date_UniqueID
		$dir = self::dir();
		if ( ! is_dir( $dir ) || ! wp_is_writable( $dir ) ) {
			self::fail( 'پوشه ذخیره فیش قابل نوشتن نیست.', 500 );
		}
		$num  = preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $order->get_order_number() );
		$num  = $num ? $num : (string) $order->get_id();
		$base = sprintf( 'C2C_%s_%04d-%02d-%02d_%s', $num, $j[0], $j[1], $j[2], wp_generate_password( 12, false, false ) );
		$max  = self::MAX_MB * MB_IN_BYTES;

		if ( 'application/pdf' === $mime ) {
			// PDF: بدون فشرده‌سازی، حداکثر ۲ مگ، بررسی امضا و محتوای فعال
			if ( $size > $max ) {
				self::fail( 'حجم فایل PDF باید حداکثر ۲ مگابایت باشد.' );
			}
			$body = file_get_contents( $tmp );
			if ( 0 !== strpos( (string) $body, '%PDF-' ) ) {
				self::fail( 'فایل PDF معتبر نیست.' );
			}
			if ( preg_match( '#/(JavaScript|JS|Launch|EmbeddedFile)\b#', $body ) ) {
				self::fail( 'این PDF محتوای فعال (اسکریپت یا فایل پیوست) دارد و پذیرفته نمی‌شود.' );
			}
			$name = $base . '.pdf';
			$dest = trailingslashit( $dir ) . $name;
			if ( ! move_uploaded_file( $tmp, $dest ) ) {
				self::fail( 'ذخیره فیش انجام نشد.', 500 );
			}
		} else {
			// تصویر: بازسازی (حذف متادیتا) + فشرده‌سازی تا زیر ۲ مگ، ذخیره به JPG
			if ( $size > self::MAX_IN_MB * MB_IN_BYTES ) {
				self::fail( 'حجم تصویر باید حداکثر ۱۰ مگابایت باشد.' );
			}
			$test = wp_get_image_editor( $tmp );
			if ( is_wp_error( $test ) ) {
				self::fail( 'این فرمت تصویر روی سرور پشتیبانی نمی‌شود. لطفاً JPG یا PNG ارسال کنید.' );
			}
			$sz = $test->get_size();
			if ( $sz['width'] < 50 || $sz['height'] < 50 ) {
				self::fail( 'تصویر معتبر نیست.' );
			}
			unset( $test );
			$name = $base . '.jpg';
			$dest = trailingslashit( $dir ) . $name;
			$mime = 'image/jpeg';
			$px   = self::MAX_PX;
			$q    = 82;
			$ok   = false;
			for ( $i = 0; $i < 6; $i++ ) {
				$e = wp_get_image_editor( $tmp );
				if ( is_wp_error( $e ) ) {
					break;
				}
				$s = $e->get_size();
				if ( $s['width'] > $px || $s['height'] > $px ) {
					$e->resize( $px, $px, false );
				}
				$e->set_quality( $q );
				$r = $e->save( $dest, 'image/jpeg' );
				clearstatcache( true, $dest );
				if ( ! is_wp_error( $r ) && file_exists( $dest ) && filesize( $dest ) <= $max ) {
					$ok = true;
					break;
				}
				$q  = max( 50, $q - 10 );
				$px = (int) ( $px * 0.85 );
			}
			if ( ! $ok ) {
				@unlink( $dest );
				self::fail( 'فشرده‌سازی تصویر ممکن نشد. لطفاً تصویر کوچک‌تری ارسال کنید.' );
			}
		}
		@chmod( $dest, 0644 );

		$order->update_meta_data( self::M_PATH, $dest );
		$order->update_meta_data( self::M_NAME, $name );
		$order->update_meta_data( self::M_DATE, $jdate );
		$order->update_meta_data( self::M_GDATE, $gdate );
		$order->update_meta_data( self::M_MIME, $mime );
		$order->update_meta_data( self::M_DONE, 'yes' );
		$order->add_order_note( 'فیش کارت‌به‌کارت ثبت شد. تاریخ واریز: ' . self::fa( $jdate ) );
		$order->set_status( 'processing', 'فیش واریز توسط مشتری بارگذاری شد.' );
		$order->save();

		wp_send_json_success( array( 'redirect' => $order->get_checkout_order_received_url() ) );
	}

	/* ================= مدیریت ================= */

	public static function admin_box( $order ) {
		if ( ! $order instanceof WC_Order || ! self::meta( $order, self::M_DONE ) ) {
			return;
		}
		$url   = esc_url( self::view_url( $order ) );
		$thumb = self::is_pdf( $order )
			? '<span style="width:72px;height:72px;border-radius:10px;background:#dc2626;color:#fff;display:grid;place-items:center;font-weight:900">PDF</span>'
			: '<img src="' . $url . '" alt="" style="width:72px;height:72px;object-fit:cover;border-radius:10px;border:1px solid #e2e8f0">';
		echo '<div style="margin-top:14px;padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;display:flex;gap:12px;align-items:center">'
			. '<a href="' . $url . '" target="_blank" rel="noopener">' . $thumb . '</a>'
			. '<div><strong>فیش کارت‌به‌کارت</strong><br>تاریخ واریز: ' . esc_html( self::display_date( $order ) )
			. '<br><a href="' . $url . '" target="_blank" rel="noopener">مشاهده فایل</a></div></div>';
	}

	public static function view_receipt() {
		$id    = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		$order = $id ? wc_get_order( $id ) : false;
		if ( ! $order || ! self::can_view( $order ) ) {
			wp_die( 'اجازه مشاهده این فیش را ندارید.', '', array( 'response' => 403 ) );
		}
		$path   = self::meta( $order, self::M_PATH );
		$mime   = self::meta( $order, self::M_MIME );
		$real   = $path ? realpath( $path ) : false;
		$inside = false;
		foreach ( self::bases() as $b ) {
			if ( $real && 0 === strpos( wp_normalize_path( $real ), trailingslashit( wp_normalize_path( $b ) ) ) ) {
				$inside = true;
				break;
			}
		}
		if ( ! $inside || ! is_file( $real ) || ! isset( self::$mimes[ $mime ] ) ) {
			wp_die( 'فایل فیش پیدا نشد.', '', array( 'response' => 404 ) );
		}
		nocache_headers();
		header( 'Content-Type: ' . $mime );
		header( 'Content-Disposition: inline; filename="' . sanitize_file_name( basename( $real ) ) . '"' );
		header( 'Content-Length: ' . filesize( $real ) );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Cache-Control: private, no-store, max-age=0' );
		if ( 0 === strpos( $mime, 'image/' ) ) {
			header( "Content-Security-Policy: default-src 'none'; img-src 'self'" );
		}
		readfile( $real );
		exit;
	}

	/* ================= CSS ================= */

	private static function css() {
		return <<<'CSS'
.c508-ov,.c508-wrap{--c5p:#3b82f6;--c5v:#8b5cf6;--c5sh:0 1px 2px rgba(16,24,40,.06),0 1px 3px rgba(16,24,40,.05);direction:rtl;text-align:right}
.c508-ov *,.c508-wrap *{box-sizing:border-box}
.c508-lock{overflow:hidden}
.c508-ov{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(11,18,32,.55);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);opacity:0;transition:opacity .25s}
.c508-ov.is-open{opacity:1}
.c508-md{width:min(520px,100%);max-height:92vh;overflow:auto;background:#fff;border-radius:24px;box-shadow:0 20px 50px rgba(11,18,32,.25);transform:translateY(16px) scale(.98);transition:transform .3s cubic-bezier(.2,.8,.2,1)}
.c508-ov.is-open .c508-md{transform:none}
.c508-hd{position:relative;overflow:hidden;padding:24px 24px 20px;color:#fff;background:radial-gradient(300px 140px at 85% -20%,rgba(255,255,255,.25),transparent 60%),linear-gradient(135deg,#1e40af,#3b82f6 55%,#8b5cf6)}
.c508-hd h3{margin:0 0 6px;font-size:19px;font-weight:900;color:#fff}
.c508-hd p{margin:0;font-size:13.5px;line-height:1.9;color:rgba(255,255,255,.85);max-width:90%}
.c508-x{position:absolute!important;top:14px;left:14px;width:36px;height:36px;border:1px solid rgba(255,255,255,.3)!important;border-radius:12px!important;background:rgb(255 255 255 / 37%)!important;line-height:1!important;cursor:pointer!important;transition:background .2s,transform .2s!important;font-size:20px!important}
.c508-x:hover{background:rgba(255,255,255,.5)!important;transform:rotate(90deg)}
.c508-bd{padding:20px 24px}
.c508-amt{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 16px;padding:12px 16px;border-radius:14px;background:#eef2ff;color:#3730a3;font-size:13.5px;border:3px solid}
.c508-amt b{font-size:17px;font-weight:900}
.c508-card{position:relative;overflow:hidden;margin:0 0 12px;padding:18px;border-radius:18px;color:#fff;background:linear-gradient(135deg,#0b1220,#1e2a5a 55%,#4c1d95);box-shadow:var(--c5sh)}
.c508-card::before{content:"";position:absolute;width:220px;height:220px;left:-60px;top:-90px;border-radius:50%;background:radial-gradient(circle,rgba(139,92,246,.55),transparent 70%);animation:c508Glow 6s ease-in-out infinite alternate}
.c508-card>*{position:relative}
.c508-card-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;font-size:13px;font-weight:800;opacity:.9}
.c508-chip{width:40px;height:30px;border-radius:7px;background:linear-gradient(135deg,#fde68a,#f59e0b);box-shadow:inset 0 0 0 1px rgba(0,0,0,.15)}
.c508-num-row,.c508-iban-row{display:flex;align-items:center;justify-content:flex-end;gap:10px;flex-wrap:wrap}
.c508-num{direction:ltr;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:20px;font-weight:700;letter-spacing:2px}
.c508-iban-row{margin-top:10px;padding-top:10px;border-top:1px dashed rgba(255,255,255,.2)}
.c508-iban-row small{opacity:.7}
.c508-iban{flex:1;direction:ltr;text-align:left;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:17.5px;word-break:break-all;opacity:.9}
.c508-holder{margin-top:12px;font-size:13.5px;font-weight:700;opacity:.9}
.c508-copy{flex:0 0 auto;padding:5px 12px!important;border:1px solid rgba(255,255,255,.3)!important;border-radius:10px!important;background:rgba(255,255,255,.14)!important;color:#fff!important;font:inherit;font-size:12px!important;font-weight:700!important;cursor:pointer!important;transition:background .2s!important}
.c508-copy:hover{background:rgba(255,255,255,.26)!important}
.c508-copy.is-done{background:#22c55e!important;border-color:#22c55e!important}
.c508-help{color:#6b7280;font-size:13.5px}
.c508-lbl{display:block;margin:16px 0 8px;font-size:13.5px;font-weight:800;color:#111827}
.c508-date{display:grid;grid-template-columns:1fr 1.5fr 1.1fr;gap:8px}
.c508-date select{width:100%!important;height:46px!important;padding:0 10px!important;border:1px solid #e5e7eb!important;border-radius:12px!important;background:#f8fafc;font:inherit;font-size:14px!important;color:#111827!important;cursor:pointer;transition:border-color .2s,box-shadow .2s!important}
.c508-date select:focus{outline:0;border-color:var(--c5p)!important;box-shadow:0 0 0 3px rgba(59,130,246,.15)}
.c508-drop{display:flex;flex-direction:column;align-items:center;gap:6px;margin:0;padding:24px 16px;border:2px dashed #c7d2fe;border-radius:18px;background:#f8faff;text-align:center;cursor:pointer;transition:all .2s}
.c508-drop:hover,.c508-drop.is-over{border-color:var(--c5p);background:#eef2ff;transform:scale(1.01)}
.c508-drop b{font-size:14px;color:#1f2937}
.c508-drop small{font-size:12px;color:#6b7280}
.c508-up{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,var(--c5p),var(--c5v));position:relative;animation:c508Bob 2.4s ease-in-out infinite}
.c508-up::after,.c508-cta-ic::after{content:"";position:absolute;inset:12px;background:#fff;-webkit-mask:var(--m) center/contain no-repeat;mask:var(--m) center/contain no-repeat}
.c508-up{--m:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/%3E%3Cpolyline points='17 8 12 3 7 8'/%3E%3Cline x1='12' y1='3' x2='12' y2='15'/%3E%3C/svg%3E")}
.c508-prev{display:none;align-items:center;gap:12px;padding:10px;border:1px solid #eef0f4;border-radius:16px;background:#fff;box-shadow:var(--c5sh);animation:c508In .3s ease}
.c508-prev img{width:64px;height:64px;object-fit:cover;border-radius:12px}
.c508-prev div{flex:1;min-width:0}
.c508-prev b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13.5px;color:#111827;direction:ltr;text-align:right}
.c508-prev small{font-size:12px;color:#6b7280}
.c508-prev.is-doc img{display:none}
.c508-prev.is-doc::before{content:attr(data-ext);flex:0 0 64px;height:64px;border-radius:12px;display:grid;place-items:center;font-size:13px;font-weight:900;color:#fff;background:linear-gradient(135deg,#ef4444,#b91c1c)}
.c508-rm{width:34px;height:34px;border:0;border-radius:10px;background:#fef2f2;color:#ef4444;font-size:20px;line-height:1;cursor:pointer}
.c508-file.has-file .c508-drop{display:none}
.c508-file.has-file .c508-prev{display:flex}
.c508-msg{margin-top:12px;font-size:13.5px;border-radius:12px}
.c508-msg:empty{display:none}
.c508-msg.error{padding:10px 14px;background:#fef2f2;color:#b91c1c}
.c508-ft{padding:0 24px 24px}
.c508-submit,.c508-btn{position:relative!important;border:0!important;border-radius:14px!important;color:#fff!important;font:inherit;font-weight:800!important;cursor:pointer!important;background:linear-gradient(135deg,var(--c5p),var(--c5v))!important;transition:transform .2s,opacity .2s!important}
.c508-submit{width:100%;height:52px;font-size:15px}
.c508-submit:hover,.c508-btn:hover{transform:translateY(-2px)}
.c508-submit:disabled{opacity:.7;cursor:wait!important;transform:none}
.c508-submit.is-loading{color:transparent!important}
.c508-submit.is-loading::after{content:"";position:absolute;top:50%;left:50%;width:22px;height:22px;margin:-11px 0 0 -11px;border:3px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:c508Spin .7s linear infinite}
.c508-success{display:flex;flex-direction:column;align-items:center;gap:8px;padding:30px 10px;text-align:center}
.c508-success b{font-size:17px;color:#111827}
.c508-success span{font-size:13.5px;color:#6b7280}
.c508-check{position:relative;width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,#4ade80,#16a34a);animation:c508Pop .5s cubic-bezier(.2,1.4,.4,1)}
.c508-check::after{content:"";position:absolute;left:26px;top:18px;width:16px;height:30px;border:solid #fff;border-width:0 5px 5px 0;transform:rotate(45deg)}
.c508-wrap{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin:0 0 20px;padding:18px;background:#fff;border:1px solid #eef0f4;border-radius:20px;box-shadow:var(--c5sh)}
.c508-cta-ic{position:relative;flex:0 0 52px;height:52px;border-radius:16px;background:linear-gradient(135deg,#fbbf24,#f97316);animation:c508Ring 2s infinite}
.c508-cta-ic{--m:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='1' y='4' width='22' height='16' rx='2'/%3E%3Cline x1='1' y1='10' x2='23' y2='10'/%3E%3C/svg%3E")}
.c508-cta-t,.c508-done-t{flex:1;min-width:200px}
.c508-cta-t b,.c508-done-t b{display:flex;align-items:center;gap:8px;font-size:15px;font-weight:900;color:#111827}
.c508-cta-t span,.c508-done-t span{display:block;margin-top:2px;font-size:13.5px;color:#4b5563}
.c508-done-t small{display:block;font-size:12px;color:#94a3b8}
.c508-btn{padding:12px 22px;font-size:14px}
.c508-done{border-color:#bbf7d0;background:linear-gradient(180deg,#fff,#f0fdf4)}
.c508-ok{width:22px;height:22px;border-radius:50%;background:#22c55e;position:relative;flex:0 0 22px}
.c508-ok::after{content:"";position:absolute;left:8px;top:4px;width:5px;height:10px;border:solid #fff;border-width:0 2.5px 2.5px 0;transform:rotate(45deg)}
.c508-thumb{display:block;flex:0 0 84px;height:84px;overflow:hidden;border-radius:14px;border:1px solid #e5e7eb;cursor:zoom-in}
.c508-thumb img{width:100%;height:100%;object-fit:cover;transition:transform .4s}
.c508-thumb:hover img{transform:scale(1.08)}
.c508-pdf{display:flex!important;flex-direction:column;align-items:center;justify-content:center;gap:2px;border:0;background:linear-gradient(135deg,#ef4444,#b91c1c);color:#fff!important;text-decoration:none!important;cursor:pointer!important;transition:transform .25s}
.c508-pdf:hover{transform:translateY(-2px)}
.c508-pdf span{font-size:24px;line-height:1}
.c508-pdf b{font-size:13px;font-weight:900}
.c508-lb img{max-width:92vw;max-height:86vh;border-radius:16px;box-shadow:0 20px 50px rgba(0,0,0,.4);animation:c508In .3s ease}
.c508-lb .c508-x{top:18px;left:18px}
@keyframes c508Spin{to{transform:rotate(360deg)}}
@keyframes c508Bob{50%{transform:translateY(-5px)}}
@keyframes c508Glow{to{transform:translate(40px,30px) scale(1.2)}}
@keyframes c508In{from{opacity:0;transform:scale(.96)}}
@keyframes c508Pop{from{transform:scale(0)}}
@keyframes c508Ring{0%{box-shadow:0 0 0 0 rgba(249,115,22,.45)}70%{box-shadow:0 0 0 10px rgba(249,115,22,0)}}
@media(max-width:600px){
.c508-ov:not(.c508-lb){align-items:flex-end;padding:0}
.c508-ov:not(.c508-lb) .c508-md{border-radius:24px 24px 0 0;max-height:94vh;transform:translateY(100%)}
.c508-ov.is-open:not(.c508-lb) .c508-md{transform:none}
.c508-bd{padding:16px}.c508-ft{padding:0 16px 20px}
.c508-num{font-size:17px;letter-spacing:1px}
.c508-btn{width:100%}
}
@media(prefers-reduced-motion:reduce){.c508-ov *,.c508-wrap *{animation:none!important;transition:none!important}}
CSS;
	}

	/* ================= JS ================= */

	private static function js() {
		return <<<'JS'
jQuery(function(){
	var J = jQuery, C = window.C508C2C || {}, S = C.s || {}, cur = {};
	var fa  = function(s){ return String(s).replace(/\d/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[d]; }); };
	var esc = function(s){ return J('<div>').text(s == null ? '' : s).html().replace(/"/g, '&quot;'); };
	var pad = function(n){ return ('0' + n).slice(-2); };
	var grp = function(n){ n = String(n).replace(/[\s-]/g, ''); return /^\d{16}$/.test(n) ? n.replace(/(\d{4})(?=\d)/g, '$1 ') : n; };
	var copyBtn = function(v){ return '<button type="button" class="c508-copy" data-copy="' + esc(v) + '">' + S.copy + '</button>'; };

	function modal(o){
		var h = '<div class="c508-ov" role="dialog" aria-modal="true"><div class="c508-md">';
		h += '<div class="c508-hd"><button type="button" class="c508-x" aria-label="بستن">×</button><h3>' + S.title + '</h3><p>' + S.desc + '</p></div><div class="c508-bd">';
		if (o.total) h += '<div class="c508-amt"><span>' + S.amount + '</span><b>' + esc(o.total) + '</b></div>';
		var acc = C.accounts || [];
		acc.forEach(function(a){
			h += '<div class="c508-card"><div class="c508-card-top"><i class="c508-chip"></i><span>' + esc(a.bank_name || '') + '</span></div>';
			if (a.account_number) h += '<div class="c508-num-row"><span class="c508-num">' + esc(grp(a.account_number)) + '</span>' + copyBtn(a.account_number) + '</div>';
			if (a.iban) h += '<div class="c508-iban-row"><small>شبا</small><span class="c508-iban">' + esc(a.iban) + '</span>' + copyBtn(a.iban) + '</div>';
			if (a.account_name) h += '<div class="c508-holder">' + esc(a.account_name) + '</div>';
			h += '</div>';
		});
		if (!acc.length) h += '<p class="c508-help">' + S.noAcc + '</p>';

		var t = C.today || [1405, 1, 1], i;
		h += '<label class="c508-lbl">' + S.date + '</label><div class="c508-date"><select class="c508-d" aria-label="روز">';
		for (i = 1; i <= 31; i++) h += '<option value="' + i + '"' + (i === t[2] ? ' selected' : '') + '>' + fa(i) + '</option>';
		h += '</select><select class="c508-m" aria-label="ماه">';
		for (i = 1; i <= 12; i++) h += '<option value="' + i + '"' + (i === t[1] ? ' selected' : '') + '>' + C.months[i - 1] + '</option>';
		h += '</select><select class="c508-y" aria-label="سال"><option value="' + t[0] + '">' + fa(t[0]) + '</option><option value="' + (t[0] - 1) + '">' + fa(t[0] - 1) + '</option></select></div>';

		h += '<label class="c508-lbl">' + S.file + '</label><div class="c508-file"><label class="c508-drop"><input type="file" accept="image/*,application/pdf,.heic,.heif" hidden><i class="c508-up"></i><b>' + S.drop + '</b><small>' + S.types + '</small></label>';
		h += '<div class="c508-prev"><img alt=""><div><b class="c508-fn"></b><small class="c508-fs"></small></div><button type="button" class="c508-rm" aria-label="حذف">×</button></div></div>';
		h += '<div class="c508-msg" aria-live="polite"></div></div><div class="c508-ft"><button type="button" class="c508-submit">' + S.submit + '</button></div></div></div>';
		return h;
	}

	function open(o){
		cur = o;
		J('.c508-ov').remove();
		J('body').addClass('c508-lock').append(modal(o));
		requestAnimationFrame(function(){ J('.c508-ov').addClass('is-open'); });
	}

	function close(ov){
		if (ov.hasClass('c508-lb')) { ov.remove(); return; }
		if (!cur.done && cur.checkout && !window.confirm(S.close)) return;
		ov.removeClass('is-open');
		setTimeout(function(){ ov.remove(); J('body').removeClass('c508-lock'); }, 250);
		if (!cur.done && cur.checkout && cur.redirect) window.location.replace(cur.redirect);
	}

	function msg(t, type){ J('.c508-msg').attr('class', 'c508-msg ' + (type || '')).text(t || ''); }

	function setFile(f){
		var box = J('.c508-file'), prev = box.find('.c508-prev');
		msg('');
		if (!f) return;
		var isPdf  = f.type === 'application/pdf' || /\.pdf$/i.test(f.name),
		    isHeic = /\.(heic|heif)$/i.test(f.name) || /heic|heif/.test(f.type),
		    isImg  = /^image\//.test(f.type) || isHeic;
		if (!isPdf && !isImg) { msg(S.badType, 'error'); box.find('input').val(''); return; }
		if (isPdf && f.size > (C.maxPdf || 2) * 1048576) { msg(S.bigPdf, 'error'); box.find('input').val(''); return; }
		if (isImg && f.size > (C.maxImg || 10) * 1048576) { msg(S.big, 'error'); box.find('input').val(''); return; }
		prev.toggleClass('is-doc', isPdf || isHeic).attr('data-ext', isPdf ? 'PDF' : 'HEIC');
		prev.find('img').attr('src', (isPdf || isHeic) ? '' : URL.createObjectURL(f));
		box.find('.c508-fn').text(f.name);
		box.find('.c508-fs').text(f.size < 1048576 ? fa(Math.round(f.size / 1024)) + ' کیلوبایت' : fa((f.size / 1048576).toFixed(1)) + ' مگابایت');
		box.addClass('has-file');
	}

	/* باز کردن پاپ‌آپ از پنل کاربری */
	J(document).on('click', '.c508-open', function(e){
		e.preventDefault();
		var b = J(this);
		open({ id: b.data('order'), key: b.data('key'), total: b.data('total') });
	});

	/* بستن */
	J(document).on('click', '.c508-x', function(){ close(J(this).closest('.c508-ov')); });
	J(document).on('click', '.c508-ov', function(e){ if (e.target === this) close(J(this)); });
	J(document).on('keydown', function(e){ if (e.key === 'Escape' && J('.c508-ov').length) close(J('.c508-ov').last()); });

	/* کپی */
	J(document).on('click', '.c508-copy', function(){
		var b = J(this), v = String(b.data('copy'));
		var done = function(){ b.addClass('is-done').text(S.copied); setTimeout(function(){ b.removeClass('is-done').text(S.copy); }, 1600); };
		if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(v).then(done); }
		else { var t = J('<textarea>').val(v).appendTo('body').select(); document.execCommand('copy'); t.remove(); done(); }
	});

	/* فایل + Drag & Drop */
	J(document).on('change', '.c508-file input', function(){ setFile(this.files[0]); });
	J(document).on('dragenter dragover', '.c508-drop', function(e){ e.preventDefault(); J(this).addClass('is-over'); });
	J(document).on('dragleave drop', '.c508-drop', function(e){ e.preventDefault(); J(this).removeClass('is-over'); });
	J(document).on('drop', '.c508-drop', function(e){
		var fs = e.originalEvent.dataTransfer && e.originalEvent.dataTransfer.files;
		if (fs && fs.length) { J(this).find('input')[0].files = fs; setFile(fs[0]); }
	});
	J(document).on('click', '.c508-rm', function(){ J('.c508-file').removeClass('has-file').find('input').val(''); });

	/* ثبت فیش */
	J(document).on('click', '.c508-submit', function(){
		var btn = J(this), inp = J('.c508-file input')[0], f = inp && inp.files[0];
		if (!f) { msg(S.noFile, 'error'); return; }
		var date = J('.c508-y').val() + '/' + pad(J('.c508-m').val()) + '/' + pad(J('.c508-d').val());
		var fd = new FormData();
		fd.append('action', 'c508_c2c_upload');
		fd.append('nonce', C.nonce);
		fd.append('order_id', cur.id);
		fd.append('order_key', cur.key || '');
		fd.append('transfer_date', date);
		fd.append('receipt', f);
		btn.prop('disabled', true).addClass('is-loading');
		msg('');
		J.ajax({ url: C.ajax, type: 'POST', data: fd, processData: false, contentType: false, dataType: 'json' })
		.done(function(r){
			if (r && r.success) {
				cur.done = true;
				J('.c508-bd').html('<div class="c508-success"><i class="c508-check"></i><b>' + S.ok + '</b><span>' + S.wait + '</span></div>');
				J('.c508-ft').remove();
				setTimeout(function(){
					if (cur.checkout && r.data && r.data.redirect) window.location.replace(r.data.redirect);
					else window.location.reload();
				}, 1400);
			} else {
				msg((r && r.data && r.data.message) || S.fail, 'error');
				btn.prop('disabled', false).removeClass('is-loading');
			}
		})
		.fail(function(x){
			msg((x.responseJSON && x.responseJSON.data && x.responseJSON.data.message) || S.fail, 'error');
			btn.prop('disabled', false).removeClass('is-loading');
		});
	});

	/* نمایش تصویر فیش در پاپ‌آپ (PDF در تب جدید باز می‌شود) */
	J(document).on('click', '.c508-thumb:not(.c508-pdf)', function(e){
		e.preventDefault();
		J('body').append('<div class="c508-ov c508-lb is-open"><button type="button" class="c508-x" aria-label="بستن">×</button><img src="' + esc(J(this).data('full')) + '" alt="فیش واریز"></div>');
	});

	/* چک‌اوت: به‌جای ریدایرکت، پاپ‌آپ باز شود */
	J('form.checkout').on('checkout_place_order_success', function(e, r){
		if (!r || !r.c508) return;
		J(this).removeClass('processing').unblock();
		open({ id: r.c508.id, key: r.c508.key, total: r.c508.total, checkout: true, redirect: r.redirect });
		return false;
	});
});
JS;
	}
}

C508_Card2Card_Receipt::init();

}
