<?php
/*
Plugin Name: 508 Dark Mode
Plugin URI: https://github.com/SaeedBoroo/WordPress_Plugins
Description: Adds Dark Mode toggle using <strong>DarkReader</strong>.
Version: 1.0
Requires at least: 5.8
Requires PHP: 7.2
Author: Saeed Boroomand
License: GPLv2 or later
*/


if (!defined('ABSPATH')) exit;

/* -----------------------------
   1. Load DarkReader EARLY
----------------------------- */

add_action('wp_enqueue_scripts', function () {

    wp_register_script(
        'load_darkreader_js',
        plugin_dir_url(__FILE__) . 'assets/js/darkreader.min.js',
        [],
        '4.9.105',
        false // load in HEAD (important)
    );
    wp_enqueue_style(
        'load-dark-mode-styles',
        plugin_dir_url(__FILE__) . 'assets/css/dark-mode.css',
        [],
        '1.0'
    );

    wp_enqueue_script('load_darkreader_js');

}, 1);


/* -----------------------------
   2. Footer Logic
----------------------------- */

add_action('wp_footer', function () { ?>
<script>
document.addEventListener('DOMContentLoaded', function () {

    if (localStorage.getItem('dark_mode') === 'true') {
        if (typeof DarkReader !== 'undefined') {
            setTheme508('dark');
        }
    }

});

function setTheme508(theme) {

    if (typeof DarkReader === 'undefined') return;

    if (theme === 'dark') {

        DarkReader.enable({
            brightness: 100,
            contrast: 90,
            sepia: 10
        });

        document.querySelectorAll('[id^="theme-switch-"]').forEach(input => input.checked = true);
        localStorage.setItem('dark_mode', 'true');

    } else {

        DarkReader.disable();
        document.querySelectorAll('[id^="theme-switch-"]').forEach(input => input.checked = false);
        localStorage.setItem('dark_mode', 'false');

    }
}
</script>
<?php });


/* -----------------------------
   3. Shortcode
----------------------------- */

add_shortcode('508_dark_mode', function () {

    static $instance = 0;
    $instance++;

    $toggle_id = 'theme-switch-' . $instance;

    ob_start(); ?>

    <div class="sb508-theme-toggle">
        <label class="switch">
            <input type="checkbox"
                   id="<?php echo esc_attr($toggle_id); ?>"
                   onchange="setTheme508(this.checked ? 'dark' : 'light')">
            <span class="slider">
                <span class="icon light">☀️</span>
                <span class="icon dark">🌙</span>
            </span>
        </label>
    </div>

    <?php return ob_get_clean();

});


/* -----------------------------
   4. Admin Settings
----------------------------- */

add_action('admin_menu', function () {

    add_options_page(
        '508 Dark Mode',
        '508 Dark Mode',
        'manage_options',
        '508-dark-mode',
        'sb508_settings_page'
    );

});


function sb508_settings_page() {

    if (isset($_POST['sb508_save_settings'])) {

        check_admin_referer('sb508_settings_nonce');

        if (isset($_POST['sb508_auto_mobile'])) {
            update_option('sb508_auto_mobile', '1');
        } else {
            update_option('sb508_auto_mobile', '0');
        }
    }
?>

<div class="wrap">
    <h1>508 Dark Mode</h1>

    <h2>Shortcode</h2>
    <input type="text" value="[508_dark_mode]" readonly style="width:300px">

    <h2>Mobile Menu</h2>

    <form method="post">

        <?php wp_nonce_field('sb508_settings_nonce'); ?>

        <label>
            <input type="checkbox" name="sb508_auto_mobile"
            <?php checked(get_option('sb508_auto_mobile'), '1'); ?>>
            Add toggle automatically to mobile menu
        </label>

        <br><br>

        <input type="submit"
               name="sb508_save_settings"
               class="button button-primary"
               value="Save">

    </form>

</div>

<?php
}



/* -----------------------------
   5. Inject into Mobile Menu
----------------------------- */

add_filter('wp_nav_menu_items', function ($items, $args) {

    if (get_option('sb508_auto_mobile') !== '1') return $items;

    if (
        $args->theme_location === 'mobile-menu' ||
        strpos($args->menu_class, 'mobile-menu') !== false
    ) {
        $toggle = do_shortcode('[508_dark_mode]');
        return $toggle . $items;
    }

    return $items;

}, 10, 2);

