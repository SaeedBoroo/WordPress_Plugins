=== 508 Dark Mode ===
Contributors: saeed508
Tags: dark mode, night mode, darkreader, ui, accessibility
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds a lightweight dark mode toggle to any WordPress site using DarkReader.

== Description ==

508 Dark Mode is a fast and lightweight plugin that enables a smooth dark mode experience without modifying your theme.

It uses the DarkReader engine to dynamically render a dark version of your website while preserving design integrity.

Features:

* User-controlled dark mode toggle
* Shortcode support
* Optional mobile menu injection
* Saves user preference via localStorage
* Theme-independent
* Works with Elementor & Gutenberg

Use the shortcode anywhere:

[508_dark_mode]

== Installation ==

1. Upload the plugin to /wp-content/plugins/
2. Activate it
3. Go to Settings → 508 Dark Mode
4. Add shortcode where needed

== Frequently Asked Questions ==

= Does this modify my theme? =
No. Dark mode is applied dynamically in the browser.

= Will it affect performance? =
No noticeable impact.

= Can I disable mobile auto-injection? =
Yes. From plugin settings.

== Changelog ==

= 1.0.0 =
Initial release

== Upgrade Notice ==

= 1.0.0 =
First public release
